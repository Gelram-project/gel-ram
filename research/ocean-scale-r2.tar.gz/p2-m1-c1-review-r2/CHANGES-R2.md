# R2 — verification and reproduction hardening

The measured O8/T9/P2/M1/C1 runtime is unchanged. No performance uplift is
claimed from changes to report verification and documentation.

1. Every manual Cargo command explicitly selects Rust 1.85.0. A manifest's
   `rust-version` is not a command to select that toolchain. Manual examples
   now run in a separate working copy, avoiding unlisted build outputs inside
   the strict immutable bundle. The documented target layout is explicit.
2. Added a standalone Rust checker for P2 and M1 saved logs. It checks unique
   fields, ordered acknowledgements, 1M/10M size agreement, checkpoint pins
   across storage/reload/mapping, generations, rank hashes, expected decisions,
   exact slot/byte arithmetic and positive integer timing values.
3. Five regression tests exercise wrong bank size, changed mapping pins,
   counts, rank/decision mismatches, duplicate/missing ACKs, generations,
   duplicate fields, invalid/overflowing timing values.
4. The one-command verifier now executes the full C1→R10 cross-campaign
   check, including query/top10 prefixes and corpus identity, rather than only
   comparing the per-run recalculated statistics.
5. After all builds/tests/rechecks, package membership and checksums are
   verified again, detecting unexpected changes introduced during execution.

The P2/M1 checker validates **consistency of saved evidence**, not the truth
of arbitrary logs, and not reconstruction of the large omitted banks. Hashes
are not signatures. Replaying the actual storage protocol remains a separate
opt-in campaign, with small crash/regression tests in the normal test suite.

The owner's follow-up approved the selected disclosure scope. This does not
change license terms, authenticate third-party contributions, or produce a
legal opinion. Private app/speaker/P2P, user data and keys remain excluded.
The original review archive remains byte-identical and available separately.
