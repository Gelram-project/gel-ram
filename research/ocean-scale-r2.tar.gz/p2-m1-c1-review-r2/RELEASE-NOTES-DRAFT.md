# Draft: Ocean Scale laboratory package after public v0.3.0

Public base inspected: main1079aacfeccae7e337296f332fdb2e8bed94b2e0.
This is a proposed addition, not a statement that a new tag already exists.

## New public-core candidates

- Prepared/adaptive reader experiments with bit-level comparisons against
  the included original public reader and scalar numerical oracle.
- Deterministic1M/10M generators, full scan → ranking → HIT/UNKNOWN decisions,
  raw latency series and reproducible statistics rather than headline-only times.
- Worker-count characterization at1/12/24 across three seeds, with CPU,
  memory, fault and context-switch observations at process scope.
- Larger repeated query campaigns with100 observations per class and cell.
- Snapshot/journal generations, update/delete/insert and restart/replay tests.
- Safe sealed-copy mapping, structural validation and byte-level equivalence.
- Self-contained offline dependencies, tests and hash manifests.

## Unchanged / excluded

- Existing public license terms; third-party terms are preserved separately.
- No replacement of the existing production API or default reader is implied.
- No private speaker, personal knowledge bank, chat transcripts, keys, P2P
  implementation or complete private application is included.
- Earlier public demonstration movies remain historical material. They are
  not evidence for these new scale/performance results and are not duplicated.
- Earlier uncommitted Live Lab/gel-source work is not silently bundled here.

Only measured numerical behavior is claimed. No semantic99% accuracy,
general AI understanding,4× independent storage capacity, guaranteed extreme
percentiles or synchronization with physical DRAM refresh is claimed.

The final version number and publication decision remain pending review.
