# Measurement host

- Machine: Minisforum AI X1 Pro,128GB installed RAM (owner-reported identity).
- CPU reported by Linux: AMD Ryzen AI9 HX370,24 logical CPUs.
- OS-visible RAM is approximately93.9GiB; it is not the same measurement
  as physically installed capacity. Do not relabel it as128GiB available RAM.
- Rust1.85.0. All reader/scoring paths in this bundle are CPU implementations.
- Campaigns ran with network access isolated; no model server or external LLM.
- This is a live Linux desktop, not a dedicated idle benchmark server.
- No governor, affinity, swap, THP, firmware or DRAM-refresh configuration
  was changed for the campaigns. Cold cache was not established.
- Resource guards: stop at85°C, preserve at least8GiB MemAvailable.

Per-run resource evidence is included. Worker count is not physical core
count. End-of-process RSS after freeing a bank must not be presented as the
resident memory cost of a loaded Ocean. Mapped pages, decoded banks and
ranking copies are reported separately where measured.

No claim of hardware PUF, physical-refresh synchronization or GPU-speed
comparison follows from these CPU measurements.
