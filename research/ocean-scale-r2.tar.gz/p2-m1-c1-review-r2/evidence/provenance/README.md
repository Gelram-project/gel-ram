# Original measurement pins

These are historical local manifests, not commands to run from this directory.
They retain hashes of the measured binaries (not included), producer sources,
protocols and original Cargo metadata. Original `NAME-candidate/...` sources
map to the corresponding `source/NAME-candidate/...` in this export.
Protocols map to `reports/`. Export-only Cargo license metadata and the retained
T9 rechecker guard differ as documented in SOURCE-ORIGIN.md; measured producers
and reader runtime source are unchanged. Added test files are supplemental.

The original pins were checked again successfully after the campaigns.
SOURCE-SHA256SUMS.txt covers the exact exported source, vendor and helper files;
SHA256SUMS.txt covers the complete bundle. Neither is a digital signature.
Historical binary hashes identify the measured executable, not a guarantee
that a fresh build in another path produces byte-identical machine code.
