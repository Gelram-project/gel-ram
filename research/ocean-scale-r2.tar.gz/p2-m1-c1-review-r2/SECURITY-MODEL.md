# Security model and limits

P2 and M1 are experimental Linux modules over public synthetic numeric data.
They are not a production personal-data vault or a network authorization layer.

## Covered by implementation and tests

- Bounds, format versions, counts, revision checks and canonical tombstones.
- Snapshot hash and a committed-prefix journal hash chain selected by an anchor.
- Recovery after killing the test writer at defined commit/checkpoint stages.
- Excluding cooperating concurrent writers using kernel advisory locks.
- Optional independent anchor pin; rejecting a mismatching anchor.
- M1 maps a private copy only after irreversible kernel write/resize seals.
- Changes to the source file cannot change an already-created sealed mapping.
- All returned records are explicitly decoded with checked indexes.

## Not established

- Power-loss correctness on arbitrary filesystems/storage devices.
- Resistance to an administrator, hostile process with equivalent permissions,
  malicious directory replacement, or an attacker who controls both data and
  the trusted anchor. Prechecks do not eliminate path replacement races.
- Authentication of public network authors or of semantic truth.
- Encryption, swap exclusion, cold-boot protection or hardware attestation.
- Atomic integration with private chat memory, distributed transactions or P2P.
- Automatic garbage collection, hostile-input service availability guarantees,
  or a continuously verified disk against corruption after a writer opens it.

Checksums verify consistency against a trusted value; they do not make data
unforgeable when that value is also attacker-controlled. After ambiguous I/O
failure, drop/reopen the poisoned writer and reconcile the observed revision.
Do not interpret an error as proof that nothing reached the committed anchor.

The small unsafe blocks are isolated and documented: Linux flock, memfd/seals,
read-only mmap over sealed backing and getrusage. Parsers and ranking wrappers
do not reinterpret untrusted bytes as Rust structs. Third-party implementations
are pinned and retain their own licenses; this review is not a formal proof.
