#![forbid(unsafe_code)]
use std::{
    fs::{self, File, OpenOptions},
    io::Write,
    path::Path,
    process::{Child, Command, Stdio},
    time::{Duration, Instant},
};
type Result<T> = std::result::Result<T, Box<dyn std::error::Error>>;
struct Owned(Child);
impl Drop for Owned {
    fn drop(&mut self) {
        let _ = self.0.kill();
        let _ = self.0.wait();
    }
}
fn file(p: &Path) -> std::io::Result<File> {
    OpenOptions::new().create_new(true).write(true).open(p)
}
fn sensor() -> Result<(u64, u64)> {
    let m = fs::read_to_string("/proc/meminfo")?
        .lines()
        .find_map(|l| l.strip_prefix("MemAvailable:"))
        .and_then(|l| l.split_whitespace().next())
        .ok_or("RAM")?
        .parse::<u64>()?;
    let mut temp = None;
    for e in fs::read_dir("/sys/class/hwmon")? {
        let p = e?.path();
        if fs::read_to_string(p.join("name"))
            .unwrap_or_default()
            .trim()
            == "k10temp"
        {
            temp = Some(
                fs::read_to_string(p.join("temp1_input"))?
                    .trim()
                    .parse::<u64>()?,
            );
        }
    }
    let t = temp.ok_or("temperature")?;
    if m < 8 * 1024 * 1024 || t >= 85000 {
        return Err("resource stop".into());
    }
    Ok((m, t))
}
fn main() -> Result<()> {
    let cwd = std::env::current_dir()?;
    let root = cwd.join("repeat-r10");
    fs::create_dir(&root)?;
    let mut monitor = file(&root.join("monitor.csv"))?;
    writeln!(monitor, "run,elapsed_ms,available_KiB,cpu_mC")?;
    let mut order = file(&root.join("ORDER.csv"))?;
    writeln!(order, "n,seed,workers,cycles")?;
    let cells = [
        (10_000_000, 41119),
        (1_000_000, 61141),
        (1_000_000, 41119),
        (10_000_000, 61141),
    ];
    for (n, s) in cells {
        writeln!(order, "{n},{s},24,100")?;
    }
    order.sync_all()?;
    for (n, seed) in cells {
        sensor()?;
        let name = format!("n{n}-s{seed}-w24");
        let mut child = Owned(
            Command::new(cwd.join("t9-candidate/target/release/search_tail_t9"))
                .args([n.to_string(), "24".into(), seed.to_string(), "100".into()])
                .arg(root.join(&name))
                .stdout(Stdio::from(file(&root.join(format!("{name}.log")))?))
                .stderr(Stdio::from(file(&root.join(format!("{name}.stderr")))?))
                .spawn()?,
        );
        let start = Instant::now();
        loop {
            let (m, t) = sensor()?;
            writeln!(monitor, "{name},{},{m},{t}", start.elapsed().as_millis())?;
            monitor.flush()?;
            if let Some(s) = child.0.try_wait()? {
                if !s.success() {
                    return Err(format!("{name}: {s}").into());
                }
                break;
            }
            if start.elapsed() > Duration::from_secs(900) {
                return Err("timeout".into());
            }
            std::thread::sleep(Duration::from_secs(1));
        }
        println!("{name}: complete");
    }
    monitor.sync_all()?;
    let mut f = file(&root.join("COMPLETE"))?;
    writeln!(f, "R10_COLLECTION_COMPLETE_REQUIRES_RECHECK")?;
    f.sync_all()?;
    Ok(())
}
