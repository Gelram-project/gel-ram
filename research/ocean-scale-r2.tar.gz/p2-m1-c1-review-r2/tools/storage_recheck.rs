//! Check saved P2/M1 evidence, not a substitute for rerunning the large bank.
#![forbid(unsafe_code)]
use std::{fs, path::Path};
type Result<T> = std::result::Result<T, Box<dyn std::error::Error>>;
fn require(ok: bool, message: &str) -> Result<()> {
    if ok {
        Ok(())
    } else {
        Err(message.into())
    }
}
fn field<'a>(s: &'a str, key: &str) -> Result<&'a str> {
    let prefix = format!("{key}=");
    let mut values = s.lines().filter_map(|line| line.strip_prefix(&prefix));
    let value = values.next().ok_or_else(|| format!("missing {key}"))?;
    require(values.next().is_none(), &format!("duplicate {key}"))?;
    Ok(value)
}
fn number(s: &str, key: &str) -> Result<u64> {
    Ok(field(s, key)?.parse()?)
}
fn positive(s: &str, key: &str) -> Result<u64> {
    let value = number(s, key)?;
    require(value > 0, key)?;
    Ok(value)
}
fn hash<'a>(s: &'a str, key: &str) -> Result<&'a str> {
    let h = field(s, key)?;
    require(
        h.len() == 64
            && h.bytes()
                .all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b)),
        key,
    )?;
    Ok(h)
}
#[derive(Clone)]
struct Logs {
    seed: String,
    mutate: String,
    replay: String,
    checkpoint: String,
    reload: String,
    mapped: String,
}
fn load(root: &Path, n: u64) -> Result<Logs> {
    let get = |phase| {
        fs::read_to_string(
            root.join("persistence-p2")
                .join(format!("n{n}-{phase}.log")),
        )
    };
    Ok(Logs {
        seed: get("seed")?,
        mutate: get("mutate")?,
        replay: get("replay")?,
        checkpoint: get("checkpoint")?,
        reload: get("reload")?,
        mapped: fs::read_to_string(root.join("mapping-m1").join(format!("n{n}.log")))?,
    })
}
fn check_bank(n: u64, l: &Logs) -> Result<String> {
    require(
        n == 1_000_000 || n == 10_000_000,
        "unsupported measured bank",
    )?;
    let acknowledgements: Vec<_> = l
        .mutate
        .lines()
        .filter_map(|s| s.strip_prefix("ACK_SEQUENCE="))
        .collect();
    require(acknowledgements == ["1", "2", "3", "4"], "ACK order/count")?;
    let initial = hash(&l.seed, "INITIAL_PIN")?;
    let checkpoint = hash(&l.checkpoint, "ANCHOR_PIN")?;
    let replay = hash(&l.replay, "ANCHOR_PIN")?;
    require(
        initial != replay && replay != checkpoint && initial != checkpoint,
        "anchor transition",
    )?;
    require(
        field(&l.checkpoint, "GENERATION")? == "2",
        "checkpoint generation",
    )?;
    require(
        hash(&l.reload, "ANCHOR_PIN")? == checkpoint
            && hash(&l.mapped, "ANCHOR_PIN")? == checkpoint,
        "P2/M1 checkpoint pin mismatch",
    )?;
    for (log, generation) in [(&l.replay, "1"), (&l.reload, "2")] {
        require(
            field(log, "SEQUENCE")? == "4" && field(log, "GENERATION")? == generation,
            "replay state",
        )?;
        require(
            field(log, "RECONSTRUCTION")? == "BIT_EQUAL",
            "reconstruction flag",
        )?;
        positive(log, "LOAD_VERIFY_REPLAY_NS")?;
    }
    for log in [&l.mutate, &l.replay, &l.reload] {
        positive(log, "THREE_FULL_RANKINGS_AND_COMPARISONS_NS")?;
        for (case, decision) in [
            ("updated", "HIT:Some(0)".to_owned()),
            ("deleted", "BELOW_THRESHOLD:None".into()),
            ("inserted", format!("HIT:Some({n})")),
        ] {
            let rank = format!("RANK_{case}");
            require(
                hash(log, &rank)? == hash(&l.mutate, &rank)?,
                "ranking hash changed",
            )?;
            require(
                field(log, &format!("DECISION_{case}"))? == decision,
                "unexpected decision",
            )?;
            require(
                number(log, &format!("SCORES_{case}"))? == n,
                "scores/bank size",
            )?;
        }
    }
    let slots = n.checked_add(1).ok_or("slots overflow")?;
    let bytes = slots
        .checked_mul(1153)
        .and_then(|x| x.checked_add(72))
        .ok_or("bytes overflow")?;
    require(
        number(&l.mapped, "SLOTS")? == slots && number(&l.mapped, "LIVE")? == n,
        "slot/live count",
    )?;
    require(
        number(&l.mapped, "SOURCE_BYTES")? == bytes && number(&l.mapped, "MAPPED_BYTES")? == bytes,
        "mapped byte size",
    )?;
    require(
        field(&l.mapped, "BACKING")? == "SEALED_MEMFD_COPY"
            && field(&l.mapped, "RECONSTRUCTION")? == "BIT_EQUAL",
        "mapping mode/result",
    )?;
    require(
        field(&l.mapped, "COLD_CACHE")? == "NOT_ESTABLISHED",
        "unsupported cold-cache claim",
    )?;
    hash(&l.mapped, "CANONICAL_STATE_SHA256")?;
    let times = [
        positive(&l.seed, "INITIALIZE_NS")?,
        positive(&l.mutate, "FOUR_DURABLE_OPERATIONS_NS")?,
        positive(&l.replay, "LOAD_VERIFY_REPLAY_NS")?,
        positive(&l.checkpoint, "CHECKPOINT_NS")?,
        positive(&l.reload, "LOAD_VERIFY_REPLAY_NS")?,
        positive(&l.mapped, "COPY_SEAL_MAP_VALIDATE_NS")?,
        positive(&l.mapped, "BUFFERED_LOAD_DECODE_VERIFY_NS")?,
        positive(&l.mapped, "FULL_DECODE_COMPARE_HASH_NS")?,
    ];
    Ok(format!(
        "{n},{slots},{bytes},{},{}",
        times
            .iter()
            .map(u64::to_string)
            .collect::<Vec<_>>()
            .join(","),
        checkpoint
    ))
}
fn check_evidence(root: &Path) -> Result<String> {
    for (path, expected) in [
        (
            "persistence-p2/COMPLETE",
            "P2_REPLAY_CHECKPOINT_FULL_RANKING_PASS_NOT_POWERLOSS_OR_PRIVATE_VAULT",
        ),
        (
            "mapping-m1/COMPLETE",
            "M1_COPY_SEAL_MAP_DECODE_BIT_EQUAL_NOT_ZERO_COPY_OR_COLD_CACHE",
        ),
    ] {
        require(
            fs::read_to_string(root.join(path))?.trim() == expected,
            "incomplete campaign",
        )?;
    }
    let mut csv = "initial_orbs,slots,snapshot_bytes,initialize_ns,four_commits_ns,replay_ns,checkpoint_ns,reload_ns,copy_seal_verify_ns,buffered_load_ns,compare_ns,checkpoint_pin\n".to_owned();
    for n in [1_000_000, 10_000_000] {
        csv.push_str(&check_bank(n, &load(root, n)?)?);
        csv.push('\n');
    }
    Ok(csv)
}
fn main() -> Result<()> {
    let args: Vec<_> = std::env::args_os().collect();
    require(args.len() == 2, "usage storage_recheck EVIDENCE_ROOT")?;
    print!("{}", check_evidence(Path::new(&args[1]))?);
    Ok(())
}
#[cfg(test)]
mod tests {
    use super::*;
    // Frozen, public numerical fixtures; no private banks and no large allocation.
    fn fixture() -> Logs {
        Logs {
            seed: include_str!("../evidence/persistence-p2/n1000000-seed.log").into(),
            mutate: include_str!("../evidence/persistence-p2/n1000000-mutate.log").into(),
            replay: include_str!("../evidence/persistence-p2/n1000000-replay.log").into(),
            checkpoint: include_str!("../evidence/persistence-p2/n1000000-checkpoint.log").into(),
            reload: include_str!("../evidence/persistence-p2/n1000000-reload.log").into(),
            mapped: include_str!("../evidence/mapping-m1/n1000000.log").into(),
        }
    }
    #[test]
    fn accepts_original_and_rejects_swapped_size() {
        assert!(check_bank(1_000_000, &fixture()).is_ok());
        assert!(check_bank(10_000_000, &fixture()).is_err());
    }
    #[test]
    fn rejects_missing_duplicate_and_wrong_ack() {
        for replacement in ["", "ACK_SEQUENCE=3", "ACK_SEQUENCE=4\nACK_SEQUENCE=4"] {
            let mut l = fixture();
            l.mutate = l.mutate.replace("ACK_SEQUENCE=4", replacement);
            assert!(check_bank(1_000_000, &l).is_err());
        }
    }
    #[test]
    fn rejects_disconnected_mapping_pin_and_size() {
        let mut l = fixture();
        let pin = field(&l.mapped, "ANCHOR_PIN").unwrap().to_owned();
        l.mapped = l.mapped.replace(&pin, &"a".repeat(64));
        assert!(check_bank(1_000_000, &l).is_err());
        let mut l = fixture();
        l.mapped = l.mapped.replace("SLOTS=1000001", "SLOTS=1000002");
        assert!(check_bank(1_000_000, &l).is_err());
        let mut l = fixture();
        l.mapped = l
            .mapped
            .replace("MAPPED_BYTES=1153001225", "MAPPED_BYTES=1");
        assert!(check_bank(1_000_000, &l).is_err());
    }
    #[test]
    fn rejects_changed_rank_and_false_decision() {
        let mut l = fixture();
        let rank = field(&l.reload, "RANK_updated").unwrap().to_owned();
        l.reload = l.reload.replace(&rank, &"a".repeat(64));
        assert!(check_bank(1_000_000, &l).is_err());
        let mut l = fixture();
        l.replay = l.replay.replace("BELOW_THRESHOLD:None", "HIT:Some(1)");
        assert!(check_bank(1_000_000, &l).is_err());
    }
    #[test]
    fn rejects_generation_duplicate_fields_and_invalid_time() {
        let mut l = fixture();
        l.reload = l.reload.replace("GENERATION=2", "GENERATION=1");
        assert!(check_bank(1_000_000, &l).is_err());
        let mut l = fixture();
        l.reload.push_str("SEQUENCE=4\n");
        assert!(check_bank(1_000_000, &l).is_err());
        for time in ["0", "NaN", "-1", "18446744073709551616"] {
            let mut l = fixture();
            let old = field(&l.seed, "INITIALIZE_NS").unwrap().to_owned();
            l.seed = l.seed.replace(&old, time);
            assert!(check_bank(1_000_000, &l).is_err());
        }
    }
}
