#![forbid(unsafe_code)]
use std::{fs,io::Write,path::Path};
type Result<T>=std::result::Result<T,Box<dyn std::error::Error>>;
fn main()->Result<()>{
    let args:Vec<_>=std::env::args().collect();if args.len()!=3{return Err("usage CSV NEW_SVG".into());}
    let text=fs::read_to_string(&args[1])?;let mut data=Vec::new();
    for line in text.lines().skip(1){let f:Vec<_>=line.split(',').collect();if f.len()!=9{return Err("CSV columns".into());}
        if f[2]=="EXACT"{let n=f[0].parse::<usize>()?;let w=f[1].parse::<usize>()?;let count=f[3].parse::<usize>()?;
            if ![1_000_000,10_000_000].contains(&n)||![1,12,24].contains(&w)||count!=18{return Err("chart scope".into());}
            data.push((n,w,f[4].parse::<f64>()?/1e6,f[5].parse::<f64>()?/1e6,f[6].parse::<f64>()?/1e6));
        }
    }
    if data.len()!=6{return Err("chart coverage".into());}
    let mut s=String::from("<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"1100\" height=\"730\" viewBox=\"0 0 1100 730\" role=\"img\" aria-labelledby=\"title desc\"><title id=\"title\">GEL Ocean C1: full scan and ranking by worker count</title><desc id=\"desc\">Synthetic EXACT query, 1 million and 10 million records. Bars show median end-to-end latency. Lines show min to max. Each bar represents 18 observations from three seeds. This is not semantic AI accuracy.</desc><rect width=\"1100\" height=\"730\" fill=\"#101827\"/><g font-family=\"sans-serif\" fill=\"#e7edf8\"><text x=\"48\" y=\"52\" font-size=\"28\" font-weight=\"bold\">GEL OCEAN / Full scan + ranking</text><text x=\"48\" y=\"84\" font-size=\"16\" fill=\"#b3c2d9\">C1 · synthetic Q8 · EXACT · CPU only · lower latency is better</text>");
    for (pi,n) in [1_000_000,10_000_000].iter().enumerate(){
        let y=125+pi*265;let max=if pi==0{800.0}else{6000.0};
        s.push_str(&format!("<text x=\"48\" y=\"{y}\" font-size=\"22\" font-weight=\"bold\">{}M records</text>",n/1_000_000));
        for tick in 0..=4{let x=190+tick*170;let v=max*tick as f64/4.;
            s.push_str(&format!("<line x1=\"{x}\" x2=\"{x}\" y1=\"{}\" y2=\"{}\" stroke=\"#334155\"/><text x=\"{x}\" y=\"{}\" font-size=\"13\" text-anchor=\"middle\" fill=\"#b3c2d9\">{v:.0} ms</text>",y+13,y+181,y+205));}
        for (i,w) in [1,12,24].iter().enumerate(){
            let v:Vec<_>=data.iter().filter(|v|v.0==*n&&v.1==*w).collect();if v.len()!=1{return Err("duplicate chart cell".into());}let (_,_,lo,median,hi)=*v[0];
            if !lo.is_finite()||lo<0.||median<lo||hi<median||hi>max{return Err("invalid chart values".into());}
            let yy=y+35+i*52;let width=median/max*680.;let left=190.+lo/max*680.;let right=190.+hi/max*680.;let color=["#8c9caf","#ac8bfa","#43d9ba"][i];
            s.push_str(&format!("<text x=\"48\" y=\"{}\" font-size=\"16\">{w} worker{}</text><rect x=\"190\" y=\"{}\" width=\"{width:.2}\" height=\"28\" rx=\"4\" fill=\"{color}\"/><line x1=\"{left:.2}\" x2=\"{right:.2}\" y1=\"{yy}\" y2=\"{yy}\" stroke=\"#ffffff\" stroke-width=\"2\"/><text x=\"915\" y=\"{}\" font-size=\"17\" text-anchor=\"start\">{median:.1} ms</text>",yy+5,if *w==1{""}else{"s"},yy-14,yy+5));
        }
    }
    s.push_str("<text x=\"48\" y=\"658\" font-size=\"15\">Bars: nearest-rank p50 · white lines: min–max · N=18 per bar (3 seeds × 6)</text><text x=\"48\" y=\"684\" font-size=\"14\" fill=\"#b3c2d9\">AMD Ryzen AI 9 HX 370 · Rust 1.85 · Linux · live desktop · no cold-cache claim</text><text x=\"48\" y=\"708\" font-size=\"13\" fill=\"#b3c2d9\">Source: evidence/contention-c1/rechecked-stats.csv · Independent panel scales · Not addressed-read latency</text></g></svg>");
    let p=Path::new(&args[2]);let mut out=fs::OpenOptions::new().create_new(true).write(true).open(p)?;out.write_all(s.as_bytes())?;out.sync_all()?;Ok(())
}
