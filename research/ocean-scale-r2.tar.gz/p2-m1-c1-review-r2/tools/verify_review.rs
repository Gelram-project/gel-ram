#![forbid(unsafe_code)]
use std::{
    fs,
    io::Write,
    path::Path,
    process::{Command, Output},
};
type Result<T> = std::result::Result<T, Box<dyn std::error::Error>>;
fn inventory(root: &Path, dir: &Path) -> Result<std::collections::BTreeSet<String>> {
    let mut found = std::collections::BTreeSet::new();
    for entry in fs::read_dir(dir)? {
        let entry = entry?;
        let p = entry.path();
        let m = fs::symlink_metadata(&p)?;
        check(!m.is_symlink(), "symlink in package")?;
        if m.is_dir() {
            found.extend(inventory(root, &p)?);
        } else {
            check(m.is_file(), "nonregular package entry")?;
            let s = p
                .strip_prefix(root)?
                .to_str()
                .ok_or("non-UTF8 path")?
                .to_owned();
            check(!s.contains(['\n', '\r', '\\']), "ambiguous path")?;
            found.insert(s);
        }
    }
    Ok(found)
}
fn manifest_members(text: &str) -> Result<std::collections::BTreeSet<String>> {
    let mut names = std::collections::BTreeSet::new();
    for line in text.lines() {
        let (hash, name) = line.split_once("  ").ok_or("manifest syntax")?;
        check(
            hash.len() == 64 && hash.bytes().all(|c| c.is_ascii_hexdigit()),
            "hash syntax",
        )?;
        let name = name.strip_prefix("./").unwrap_or(name);
        check(
            !name.is_empty()
                && !Path::new(name).is_absolute()
                && name
                    .split('/')
                    .all(|p| !p.is_empty() && p != "." && p != "..")
                && !name.contains(['\r', '\n', '\\']),
            "unsafe manifest path",
        )?;
        check(names.insert(name.into()), "duplicate manifest path")?;
    }
    check(!names.is_empty(), "empty manifest")?;
    Ok(names)
}
fn check_inventory(root: &Path) -> Result<()> {
    let mut all = inventory(root, root)?;
    all.remove("SHA256SUMS.txt");
    check(
        manifest_members(&fs::read_to_string(root.join("SHA256SUMS.txt"))?)? == all,
        "unlisted or missing package file",
    )?;
    let sources = all
        .into_iter()
        .filter(|p| p.starts_with("source/") || p.starts_with("tools/"))
        .collect();
    check(
        manifest_members(&fs::read_to_string(root.join("SOURCE-SHA256SUMS.txt"))?)? == sources,
        "source manifest membership differs",
    )
}
fn check(v: bool, s: &str) -> Result<()> {
    if v {
        Ok(())
    } else {
        Err(s.into())
    }
}
fn run(cmd: &mut Command, out: &Path) -> Result<Output> {
    let result = cmd.output()?;
    let mut f = fs::OpenOptions::new()
        .create_new(true)
        .write(true)
        .open(out)?;
    f.write_all(&result.stdout)?;
    f.write_all(&result.stderr)?;
    f.sync_all()?;
    check(
        result.status.success(),
        &format!("command failed; inspect {}", out.display()),
    )?;
    Ok(result)
}
fn raw_copy(from: &Path, to: &Path) -> Result<()> {
    let m = fs::symlink_metadata(from)?;
    check(!m.is_symlink(), "symlink evidence")?;
    if m.is_dir() {
        fs::create_dir(to)?;
        for e in fs::read_dir(from)? {
            let e = e?;
            if ["RECHECKED", "rechecked-stats.csv", "paired-speedups.csv"]
                .iter()
                .any(|n| e.file_name() == *n)
            {
                continue;
            }
            if e.file_name().to_string_lossy().ends_with(".stats.csv") {
                continue;
            }
            raw_copy(&e.path(), &to.join(e.file_name()))?;
        }
    } else {
        check(m.is_file(), "nonregular evidence")?;
        fs::copy(from, to)?;
    }
    Ok(())
}
fn main() -> Result<()> {
    let args: Vec<_> = std::env::args().collect();
    check(args.len() == 3, "usage PACKAGE NEW_EVIDENCE_DIRECTORY")?;
    let root = Path::new(&args[1]).canonicalize()?;
    let requested = std::env::current_dir()?.join(&args[2]);
    let parent = requested.parent().ok_or("parent")?.canonicalize()?;
    let evidence = parent.join(requested.file_name().ok_or("name")?);
    check(
        !evidence.starts_with(&root),
        "evidence must be outside immutable package",
    )?;
    fs::create_dir(&evidence)?;
    check_inventory(&root)?;
    run(
        Command::new("sha256sum")
            .args(["--check", "SHA256SUMS.txt"])
            .current_dir(&root),
        &evidence.join("manifest.log"),
    )?;
    run(
        Command::new("sha256sum")
            .args(["--check", "SOURCE-SHA256SUMS.txt"])
            .current_dir(&root),
        &evidence.join("source-manifest.log"),
    )?;
    run(
        Command::new("rustc").args(["+1.85.0", "-Vv"]),
        &evidence.join("rustc.log"),
    )?;
    run(
        Command::new("uname").arg("-srmo"),
        &evidence.join("host.log"),
    )?;
    let inventory_tests = evidence.join("inventory-tests");
    run(
        Command::new("rustc")
            .args(["+1.85.0", "--edition=2021", "--test"])
            .arg(root.join("tools/verify_review.rs"))
            .arg("-o")
            .arg(&inventory_tests),
        &evidence.join("inventory-build.log"),
    )?;
    run(
        &mut Command::new(&inventory_tests),
        &evidence.join("inventory-tests.log"),
    )?;
    let storage_tests = evidence.join("storage-tests");
    run(
        Command::new("rustc")
            .args(["+1.85.0", "--edition=2021", "--test"])
            .arg(root.join("tools/storage_recheck.rs"))
            .arg("-o")
            .arg(&storage_tests),
        &evidence.join("storage-tests-build.log"),
    )?;
    run(
        &mut Command::new(&storage_tests),
        &evidence.join("storage-tests.log"),
    )?;
    let storage = evidence.join("storage-recheck");
    run(
        Command::new("rustc")
            .args(["+1.85.0", "--edition=2021", "-O"])
            .arg(root.join("tools/storage_recheck.rs"))
            .arg("-o")
            .arg(&storage),
        &evidence.join("storage-build.log"),
    )?;
    let storage_result = run(
        Command::new(&storage).arg(root.join("evidence")),
        &evidence.join("storage-recheck.log"),
    )?;
    check(
        storage_result.stdout == fs::read(root.join("evidence/storage-rechecked.csv"))?,
        "P2/M1 report differs",
    )?;
    let home = evidence.join("cargo-home");
    let target = evidence.join("target");
    fs::create_dir(&home)?;
    for p in [
        "o8-candidate",
        "t9-candidate",
        "p2-candidate",
        "m1-candidate",
        "c1-candidate",
    ] {
        for action in ["test", "build"] {
            let mut c = Command::new("cargo");
            c.current_dir(root.join("source"))
                .env("CARGO_HOME", &home)
                .env("CARGO_TARGET_DIR", &target)
                .args([
                    "+1.85.0",
                    action,
                    "--locked",
                    "--offline",
                    "--manifest-path",
                ])
                .arg(root.join("source").join(p).join("Cargo.toml"));
            if action == "test" {
                c.args(["--workspace", "--all-targets"]);
            } else {
                c.args(["--release", "--bins"]);
            }
            run(&mut c, &evidence.join(format!("{p}-{action}.log")))?;
        }
    }
    let c1 = evidence.join("c1-raw");
    raw_copy(&root.join("evidence/contention-c1"), &c1)?;
    run(
        Command::new(target.join("release/c1_recheck")).arg(&c1),
        &evidence.join("c1-recheck.log"),
    )?;
    for name in ["RECHECKED", "rechecked-stats.csv", "paired-speedups.csv"] {
        check(
            fs::read(c1.join(name))? == fs::read(root.join("evidence/contention-c1").join(name))?,
            "C1 recomputation differs",
        )?;
    }
    let r10 = evidence.join("r10-raw");
    raw_copy(&root.join("evidence/repeat-r10"), &r10)?;
    let r10_recheck = evidence.join("r10-recheck");
    run(
        Command::new("rustc")
            .args(["+1.85.0", "--edition=2021", "-O"])
            .arg(root.join("tools/r10_recheck.rs"))
            .arg("-o")
            .arg(&r10_recheck),
        &evidence.join("r10-build.log"),
    )?;
    run(
        Command::new(&r10_recheck)
            .arg(&r10)
            .arg(&c1)
            .arg(target.join("release/tail_recheck")),
        &evidence.join("r10-recheck.log"),
    )?;
    for name in [
        "RECHECKED",
        "n10000000-s41119-w24.stats.csv",
        "n1000000-s61141-w24.stats.csv",
        "n1000000-s41119-w24.stats.csv",
        "n10000000-s61141-w24.stats.csv",
    ] {
        check(
            fs::read(r10.join(name))? == fs::read(root.join("evidence/repeat-r10").join(name))?,
            "R10 cross-campaign recheck differs",
        )?;
    }
    check_inventory(&root)?;
    run(
        Command::new("sha256sum")
            .args(["--check", "SHA256SUMS.txt"])
            .current_dir(&root),
        &evidence.join("manifest-after-tests.log"),
    )?;
    let mut f = fs::OpenOptions::new()
        .create_new(true)
        .write(true)
        .open(evidence.join("COMPLETE"))?;
    writeln!(f,"OFFLINE_SOURCE_TESTS_BUILDS_AND_EVIDENCE_RECOMPUTATION_PASS\nP2_M1_LOG_LINKS=PASS\nC1_R10_PREFIX=PASS\nPUBLICATION_NOT_PERFORMED_BY_VERIFIER=YES")?;
    f.sync_all()?;
    Ok(())
}
#[cfg(test)]
mod tests {
    use super::*;
    fn entry(name: &str) -> String {
        format!("{}  {name}\n", "a".repeat(64))
    }
    #[test]
    fn rejects_duplicates_and_unsafe_names() {
        assert!(manifest_members(&(entry("./x") + &entry("x"))).is_err());
        for name in [
            "../x",
            "/x",
            "source/../x",
            "source//x",
            "source/./x",
            "source\\x",
        ] {
            assert!(manifest_members(&entry(name)).is_err(), "{name}");
        }
        assert!(manifest_members("bad  file\n").is_err());
        assert!(manifest_members("").is_err());
    }
    struct Temp(std::path::PathBuf);
    impl Temp {
        fn new() -> Self {
            static N: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);
            let p = std::env::temp_dir().join(format!(
                "gel-inventory-{}-{}",
                std::process::id(),
                N.fetch_add(1, std::sync::atomic::Ordering::Relaxed)
            ));
            fs::create_dir(&p).unwrap();
            fs::create_dir(p.join("source")).unwrap();
            fs::write(p.join("source/a"), "fixture").unwrap();
            fs::write(p.join("SOURCE-SHA256SUMS.txt"), entry("source/a")).unwrap();
            fs::write(
                p.join("SHA256SUMS.txt"),
                entry("source/a") + &entry("SOURCE-SHA256SUMS.txt"),
            )
            .unwrap();
            Self(p)
        }
    }
    impl Drop for Temp {
        fn drop(&mut self) {
            let _ = fs::remove_dir_all(&self.0);
        }
    }
    #[test]
    fn detects_added_and_missing_files() {
        let t = Temp::new();
        assert!(check_inventory(&t.0).is_ok());
        fs::write(t.0.join("unlisted"), "extra").unwrap();
        assert!(check_inventory(&t.0).is_err());
        fs::remove_file(t.0.join("unlisted")).unwrap();
        fs::remove_file(t.0.join("source/a")).unwrap();
        assert!(check_inventory(&t.0).is_err());
    }
    #[cfg(unix)]
    #[test]
    fn rejects_symlink_even_when_name_is_listed() {
        let t = Temp::new();
        fs::remove_file(t.0.join("source/a")).unwrap();
        std::os::unix::fs::symlink("../SOURCE-SHA256SUMS.txt", t.0.join("source/a")).unwrap();
        assert!(check_inventory(&t.0).is_err());
    }
}
