#![forbid(unsafe_code)]
use std::{fs,io::Write,path::Path,process::Command};
type Result<T>=std::result::Result<T,Box<dyn std::error::Error>>;
fn field<'a>(s:&'a str,k:&str)->Result<&'a str>{let p=format!("{k}=");let v:Vec<_>=s.lines().filter_map(|l|l.strip_prefix(&p)).collect();if v.len()!=1{return Err("metadata count".into());}Ok(v[0])}
fn main()->Result<()>{
    let args:Vec<_>=std::env::args().collect();if args.len()!=4{return Err("usage R10_ROOT C1_ROOT TAIL_RECHECK_BINARY".into());}
    let root=Path::new(&args[1]);let old=Path::new(&args[2]);
    if fs::read_to_string(root.join("COMPLETE"))?.trim()!="R10_COLLECTION_COMPLETE_REQUIRES_RECHECK"{return Err("incomplete".into());}
    let mut rows=0u64;let mut bits=0u64;let mut checks=0u64;
    for (n,seed) in [(10_000_000,41119),(1_000_000,61141),(1_000_000,41119),(10_000_000,61141)]{
        let name=format!("n{n}-s{seed}-w24");let dir=root.join(&name);let before=old.join(&name);
        let run=Command::new(&args[3]).arg(&dir).args([n.to_string(),"24".into(),seed.to_string(),"100".into()]).output()?;
        if !run.status.success(){return Err(format!("recheck failed: {name} {}",String::from_utf8_lossy(&run.stderr)).into());}
        let mut f=fs::OpenOptions::new().create_new(true).write(true).open(root.join(format!("{name}.stats.csv")))?;
        f.write_all(&run.stdout)?;f.sync_all()?;
        for file in ["queries.csv","top10.csv"]{
            let new=fs::read_to_string(dir.join(file))?;let prev=fs::read_to_string(before.join(file))?;
            if !new.starts_with(&prev){return Err(format!("C1 prefix mismatch: {name} {file}").into());}
        }
        let s=fs::read_to_string(dir.join("summary.txt"))?;let prev=fs::read_to_string(before.join("summary.txt"))?;
        if field(&s,"CORPUS_SHA256")?!=field(&prev,"CORPUS_SHA256")?{return Err("C1 corpus mismatch".into());}
        rows+=field(&s,"ROWS")?.parse::<u64>()?;bits+=field(&s,"BIT_COMPARISONS")?.parse::<u64>()?;checks+=field(&s,"ORACLE_CHECKS")?.parse::<u64>()?;
    }
    if rows!=2800{return Err("row count".into());}
    let mut f=fs::OpenOptions::new().create_new(true).write(true).open(root.join("RECHECKED"))?;
    writeln!(f,"ROWS={rows}\nBIT_COMPARISONS={bits}\nORACLE_CHECKS={checks}\nC1_PREFIX_QUERY_AND_TOP10=PASS\nNOTE=100_OBSERVATIONS_PER_CLASS_CELL_NOT_EXTREME_TAIL")?;f.sync_all()?;Ok(())
}
