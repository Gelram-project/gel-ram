//! Allowlisted review export. Does not upload, activate a license or copy banks.
use std::{fs, path::Path, io::{self, Write}};
fn copy_tree(from:&Path,to:&Path)->io::Result<()> {
    let meta=fs::symlink_metadata(from)?;
    if meta.is_symlink() {return Err(io::Error::other("symlink excluded"));}
    if meta.is_dir(){fs::create_dir_all(to)?;for e in fs::read_dir(from)?{let e=e?;copy_tree(&e.path(),&to.join(e.file_name()))?;}}
    else if meta.is_file(){if to.exists(){return Err(io::Error::other("destination exists"));}if let Some(p)=to.parent(){fs::create_dir_all(p)?;}fs::copy(from,to)?;}
    else{return Err(io::Error::other("nonregular input"));} Ok(())
}
fn main()->io::Result<()> {
    let root=std::env::current_dir()?;let out=root.join("p2-m1-c1-review");
    fs::create_dir(&out)?;
    for e in fs::read_dir(root.join("review-p2-m1-c1-notes"))? {let e=e?;copy_tree(&e.path(),&out.join(e.file_name()))?;}
    copy_tree(&root.join("tools/package_p2_m1_c1.rs"),&out.join("tools/package_p2_m1_c1.rs"))?;
    for name in ["o8-candidate","t9-candidate","p2-candidate","m1-candidate","c1-candidate"] {
        for item in ["Cargo.toml","Cargo.lock","rust-toolchain.toml","src"] {copy_tree(&root.join(name).join(item),&out.join("source").join(name).join(item))?;}
        for item in ["tests","LICENSE","crates","docs"] {let src=root.join(name).join(item);if src.exists(){copy_tree(&src,&out.join("source").join(name).join(item))?;}}
    }
    copy_tree(&root.join("o8-review-package/source/tests/stratified.rs"),&out.join("source/o8-candidate/tests/stratified.rs"))?;
    let preserved_test=root.join("o8-review-package/source/tests/tail_evidence.rs");
    let exported_test=out.join("source/t9-candidate/tests/tail_evidence.rs");
    if exported_test.exists() {
        if fs::read(&preserved_test)? != fs::read(&exported_test)? {
            return Err(io::Error::other("preserved T9 test differs; review required"));
        }
    } else { copy_tree(&preserved_test,&exported_test)?; }
    // Preserve the already-tested dimension guards from the previous export.
    fs::copy(root.join("o8-review-package/source/src/bin/tail_recheck.rs"),out.join("source/t9-candidate/src/bin/tail_recheck.rs"))?;
    for file in ["C1-PROTOCOL.md","P2-PROTOCOL.md","M1-PROTOCOL.md","R10-PROTOCOL.md","RAPORT-PERSISTENCE-P2.md","RAPORT-MAPPING-M1.md","RAPORT-CONTENTION-C1.md","RAPORT-REPEAT-R10.md"] {
        copy_tree(&root.join(file),&out.join("reports").join(file))?;
    }
    // Raw numerical evidence only. Never copy data/trust directories, snapshots,
    // WAL, executables, compiler logs, environment paths, private code or models.
    for name in ["persistence-p2","mapping-m1"] {
        for e in fs::read_dir(root.join(name))? {
            let e=e?;if e.file_type()?.is_file(){copy_tree(&e.path(),&out.join("evidence").join(name).join(e.file_name()))?;}
        }
    }
    copy_tree(&root.join("contention-c1"),&out.join("evidence/contention-c1"))?;
    copy_tree(&root.join("repeat-r10"),&out.join("evidence/repeat-r10"))?;
    for tool in ["r10_campaign.rs","r10_recheck.rs","c1_chart.rs","verify_review.rs"] {copy_tree(&root.join("tools").join(tool),&out.join("tools").join(tool))?;}
    copy_tree(&root.join("p2-crash-evidence-final.txt"),&out.join("evidence/p2-crash-evidence.txt"))?;
    copy_tree(&root.join("o8-candidate/LICENSE"),&out.join("LICENSE"))?;
    for name in ["t9-candidate","p2-candidate","m1-candidate","c1-candidate"] {
        copy_tree(&root.join("o8-candidate/LICENSE"),&out.join("source").join(name).join("LICENSE"))?;
        let path=out.join("source").join(name).join("Cargo.toml");
        let original=fs::read_to_string(&path)?;
        if !original.contains("license-file") {
            fs::write(&path,original.replacen("[package]","[package]\nlicense-file = \"LICENSE\"",1))?;
        }
    }
    let mut f=fs::OpenOptions::new().create_new(true).write(true).open(out.join("EXPORT-SCOPE.txt"))?;
    writeln!(f,"REVIEW_ONLY=YES\nPUBLICATION_APPROVED=NO\nLICENSE_ACTIVATED_BY_THIS_EXPORT=NO\nPRIVATE_BANKS_INCLUDED=NO\nLARGE_SYNTHETIC_BANKS_INCLUDED=NO\nBINARIES_INCLUDED=NO\nRAW_COMPILER_LOGS_INCLUDED=NO")?;
    f.sync_all()?;Ok(())
}
