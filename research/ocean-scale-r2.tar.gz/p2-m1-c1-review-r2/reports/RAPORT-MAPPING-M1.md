# M1 — bezpieczne mapowanie kopii checkpointu

Rust1.85/Linux, lokalnie i offline. P2 oraz starsze wyniki bez zmian.
**1M i10M: wszystkie sloty zgodne bitowo z dekoderem P2.**

Nie mapujemy mutowalnego pliku dyskowego. Kopia trafia do memfd, na które
kernel nakłada seals WRITE/GROW/SHRINK/SEAL. Dopiero później powstaje mmap
read-only, walidacja struktury i całego pinu, odczyt indeksowy z kontrolą granic.
Snapshot z oczekującym WAL jest odrzucany: ten moduł nie pomija przyrostów.

| Jedna próba na rozmiar |1M żywych ORB|10M żywych ORB|
|---|---:|---:|
| Sloty wraz z tombstone |1 000 001|10 000 001|
| Mapowane bajty |1 153 001 225|11 530 001 225|
| Kopia + seals + mmap + walidacja |1,039s|7,016s|
| Buforowany load/decode/verify P2 |1,336s|13,835s|
| Dekodowanie mapy + porównanie + hash wszystkich slotów |2,518s|24,827s|
| RSS tylko po otwarciu mapy |1 128 180KiB|11 261 944KiB|
| HWM z mapą i drugim zdekodowanym bankiem |2 261 004KiB|22 590 080KiB|

Nie są to dwie równoważne operacje: mmap pozostawia rekordy w formacie
binarnym, P2 od razu tworzy rekordy Rust. **Nie ogłaszamy2× przyspieszenia
czytnika.** Bezpośredni pełny ranking po mapie bez budowania PreparedBank
nie jest jeszcze zaimplementowany. To także nie zero-copy z dysku.

Ścieżka odczytu zwraca własny Record, a nie referencję do rzutowanych struktur.
Deskryptor memfd pozostaje prywatny i może być zamknięty po mapowaniu; mmap
utrzymuje strony. Seals nie są szyfrowaniem. Strony mogą trafić do swap,
administrator nie należy do chronionego modelu zagrożeń.

## Testy i pomiary

Cztery testy Rust PASS: jeden kontroli seals/lifetime i trzy integracyjne
(tombstone, zmiana źródła po mapowaniu, granice, WAL, pusty snapshot,
błędny pin/generacja/budżet, każde pojedyncze przekłamanie bajtu małego pliku
i wybrane odcięcia). Log: `m1-tests-final.log`.
Późniejszy piąty test także przeszedł: niekanoniczny slot zostaje odrzucony
nawet po ponownym obliczeniu hasha i podaniu dopasowanego pinu.
Pełny log dodatkowej regresji: `m1-tests-supplementary.log`.

Wyniki duże: `mapping-m1/n1000000.log`, `mapping-m1/n10000000.log`;
każdy slot mapy porównany z P2, kanoniczny SHA stanu zapisany. Monitor:
`mapping-m1/monitor.csv`; COMPLETE dopiero po obu kontrolach zgodności.
Minflt/majflt i user/system ticks zapisano przed/po każdej fazie z `/proc`.
W obu próbach major faults=0; **cold cache nie został ustanowiony**.
Nie resetowano cache hosta. Wyniki kolejności mapowanie→dekoder mogą korzystać
z cache; nie są losowanym benchmarkiem A/B ani rozkładem ogonów.

Wejścia i binaria: `M1-INPUTS.sha256`, `M1-RUNTIME-BINARIES.sha256`.
Nowe zależności z istniejącego lokalnego cache: memmap2=0.9.11 i libc=0.2.186,
obie deklarują MIT OR Apache-2.0; Cargo.lock przypina wersje/checksumy.
Nie pobierano niczego ani nie zmieniono licencji GEL.
Unsafe ograniczono do osobnego modułu z opisem każdej operacji FFI/mapowania.

```sh
cd m1-candidate
cargo test --offline
cargo build --offline --release
cd ..
# Wymaga ukończonego persistence-p2 oraz braku katalogu mapping-m1:
./m1-candidate/target/release/m1_campaign
```

Nie publikowano tego modułu. Do szerszego użycia potrzebny jest jeszcze
przegląd integracji z szyfrowaniem i polityką pamięci; nie zastępuje prywatnego sejfu.
