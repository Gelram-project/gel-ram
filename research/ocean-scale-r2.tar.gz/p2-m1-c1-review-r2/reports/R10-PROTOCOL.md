# R10 — pełne powtórzenia T9, protokół przed pomiarem

Nie zmieniamy producenta T9, czytnika O8, progów ani typów pytań.
Kolejność:10M/seed41119,1M/seed61141,1M/seed41119,10M/seed61141.
24 workery,100 cykli siedmiu klas w każdej komórce. Razem2800 operacji,
w tym2400 pełnych skanów i400 pustych zapytań. Seedy były wcześniej użyte
w diagnostyce C1; to powtórzenia, nie nowe niezależne held-out dane.

Każdy przebieg zachować. Zweryfikować raw CSV, oracle, metadata i zgodność
pierwszych sześciu cykli z C1. Publikować N=100 na klasę/komórkę, p50/p95/p99,
max. Nie publikować p99.9–p99.999 jako stabilnych ogonów. Oddzielić wyniki
poszczególnych seedów i rozmiarów; nie wybrać tylko najlepszego przebiegu.

Limit:900s/komórkę, min8GiB MemAvailable, stop85°C. Jeden proces testowy naraz.
Bez wymuszania zimnego cache, ustawiania governor lub zatrzymywania aplikacji
użytkownika. Normalny pulpit może działać w tle; to nie dedykowany serwer.
