# C1 — 1/12/24 workerów na identycznych zapytaniach

Zakończono18 komórek:1M/10M, trzy seedy, trzy liczby workerów. W każdej
sześć cykli siedmiu klas. Rust1.85, niezmieniony producent T9 i czytnik O8.
Nie publikowano. Protokół i kolejność zapisano przed testem.

## Poprawność

756 operacji E2E:648 pełnych skanów i108 pustych zapytań.594 mln par score
porównanych bitowo ze ścieżką bazową bez błędów;47 952 kontrole scalar oracle.
Niezależny `c1_recheck` sprawdził konfiguracje z metadanych, tożsamość zapytań,
corpus SHA, całe zapisane top10 oraz decyzje między1/12/24. Statystyki i sumy
przeliczono z raw CSV. Trzy testy negatywne weryfikatora przeszły.

## Pełne wyszukiwanie EXACT — E2E, nie addressed read

| Rozmiar | Workery | N | p50, nearest-rank | min–max |
|---|---:|---:|---:|---:|
|1M|1|18|474,440ms|456,006–658,490ms|
|1M|12|18|77,408ms|65,528–101,818ms|
|1M|24|18|58,417ms|48,814–86,164ms|
|10M|1|18|4669,727ms|4559,423–5544,472ms|
|10M|12|18|632,334ms|603,649–904,264ms|
|10M|24|18|498,265ms|473,238–648,253ms|

To18 obserwacji z trzech seedów po sześć, nie18 niezależnych maszyn.
Mediana ilorazów czasu tego samego pytania1/24:8,124× dla1M i9,425× dla10M.
Nie jest to24× skalowanie ani deklaracja takiego zysku dla każdej klasy.
Wyniki pozostałych klas i pełne zakresy: `contention-c1/rechecked-stats.csv`
i `paired-speedups.csv`. Nie podajemy p99.9 dla tak małego N.

## Zasoby i ograniczenia

1995 próbek monitorowania; CPU max77,125°C; minimalne dostępne RAM
78 918 828KiB. Każda komórka ma osobny plik `.resources`: user/system CPU,
minor/major faults oraz voluntary/involuntary context switches z getrusage.
To liczby dla całego procesu, łącznie z generowaniem, oracle i walidacją,
nie wyłącznie dla kernela skanowania. Workery to wątki, nie fizyczne CPU.

Badanie wykonano na aktywnym pulpicie użytkownika. Nie wymuszano governor,
affinity, drop_caches ani zamknięcia innych aplikacji. Przeplatano kolejność
rozmiarów i workerów. Nie zmierzono przyczyn poszczególnych wolnych próbek;
nie przypisujemy ich automatycznie cache lub fizycznemu refresh DRAM.

Dowody: COMPLETE, RECHECKED, ORDER.csv, queries.csv, top10.csv, timings.csv,
summary.txt oraz monitor. Seedy41119/51131/61141. C1 nie zastępuje pełnego
T9 N=100 ani niezależnej oceny semantycznej. Pełniejsze powtórzenia są w R10.
