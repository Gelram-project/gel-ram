# P2 — trwałe generacje i journal, protokół przed testami

Osobna kopia eksperymentalna, Rust1.85/Linux. Tylko syntetyczne, jawne
rekordy publicznego Q8; nie prywatny sejf ani dane rozmów. P1/O8/T9 bez zmian.

Właściciel kontroluje katalog danych i oddzielny katalog zaufanego anchora.
Anchor wybiera konkretną generację, pin snapshotu i zatwierdzony prefiks WAL.
Opcjonalny pin anchora z innego kanału wykrywa także jego podmianę/rollback.
Checksum nie jest podpisem; kto może zmienić dane i anchor, może je podrobić.
Nie ma ochrony przed administratorem lub wrogą podmianą ścieżek w katalogu.

Immutable snapshot + WAL z sekwencją i łańcuchem SHA256. Insert/update/delete
mają jednoznaczne warunki; usunięte ID nie wraca do rankingu. Globalna rewizja
rośnie monotonicznie. Jeden zapisujący proces przez kernelowy flock na Linux;
minimalny audytowany FFI bez wskaźników, brak nowych pobieranych zależności.

Commit: przygotowanie RAM → WAL → fsync WAL → staging anchora → fsync pliku
→ rename CURRENT → fsync katalogu zaufanego → aktualizacja RAM → ACK.
Po niepewnym błędzie I/O sesja jest zatruta i musi zostać otwarta ponownie.
Replay czyta tylko zatwierdzony prefiks. Niepublikowany ogon po awarii nie
staje się samoczynnie wiedzą; przed kolejnym append zostaje odcięty pod blokadą.
Checkpoint tworzy nową generację i pusty journal, synchronizuje dane/katalog,
a dopiero potem publikuje anchor. Osieroconych generacji nie wybiera według
samego największego numeru. Nie nadpisuje starych snapshotów.

Testy: wszystkie odcięcia małego WAL, zmiany bajtów zatwierdzonego WAL,
limity, złe rewizje/ID/generacje, tombstones, konkurencja writerów, skażony
ogon, restart w nowym procesie oraz SIGKILL własnego dziecka w każdym hooku
publikacji. Porównać rekordy i cały ranking przed/po replay/checkpoint.
Duże próby1M/10M dopiero po małych testach, z monitorem RAM/temperatury.
Nie restartować hosta, nie twierdzić, że SIGKILL dowodzi odporności na zanik
zasilania. mmap, szyfrowanie i semantyka języka nie są częścią P2.
