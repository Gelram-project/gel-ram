# R10 — powtórzenia pełnego rankingu, bez wyboru najlepszego przebiegu

Producent T9 i czytnik O8 niezmienione. Rust 1.85.0, Linux, 24 workery.
Kolejność zapisana przed pomiarem: 10M/41119, 1M/61141, 1M/41119,
10M/61141. Seedy znane z C1; to reprodukcja, nie held-out semantyczny.

## Wynik niezależnego przeliczenia

- 2800 operacji: 2400 pełnych skanów, 400 zapytań EMPTY.
- 660 000 000 porównań bitowych wyników scoringu; brak rozbieżności.
- 177 600 sprawdzeń oracle; poprawne oczekiwane decyzje i rankingi.
- Pierwszych sześć cykli każdego przebiegu ma identyczne zapytania i top10
  jak C1, przy tym samym hashu korpusu. Czasów nie oczekujemy identycznych.
- Statystyki wyliczone ponownie z CSV przez `tail_recheck`, a zgodność
  z C1 sprawdzona przez `tools/r10_recheck.rs`.

## EXACT — pełny scan → top10 → decyzja, milisekundy

| ORB | Seed | N | p50 | p95 | p99 | max |
|---|---|---|---|---|---|---|
| 1M | 41119 | 100 | 72.427 | 81.018 | 82.859 | 90.949 |
| 1M | 61141 | 100 | 71.962 | 79.860 | 80.576 | 88.227 |
| 10M | 41119 | 100 | 615.428 | 684.888 | 710.313 | 734.085 |
| 10M | 61141 | 100 | 704.995 | 757.900 | 783.038 | 810.236 |

Wszystkie siedem klas, min/mean/stddev i liczba unikalnych zapytań są w
`evidence/repeat-r10/*.stats.csv` w eksporcie (lokalnie `repeat-r10/`).
Surowe latency, queries i top10 pozostają w podkatalogach każdego przebiegu.
TIE ma tylko jedno unikalne zapytanie; EMPTY nie wykonuje pełnego skanu.

To istotna granica: dłuższa kampania nie powtórzyła krótkiego C1 z p50
około 498 ms dla 10M/24. Nie zastępujemy jej ładniejszym wynikiem C1.
Zmieniał się seed i stan działającego komputera; nie przypisujemy różnicy
konkretnej przyczynie sprzętowej bez osobnego testu. 24 workery nie są
gwarancją stałego latency ani 24-krotnego przyspieszenia.

N=100 na klasę i komórkę nie uzasadnia stabilnego p99.9–p99.999.
Nawet p99 jest tu oszacowaniem bardzo wrażliwym na pojedyncze obserwacje.
Próby są syntetyczne i nie mierzą rozumienia języka ani recall wiedzy AI.

## Kontrola zasobów

790 próbek monitora; maksymalna zaobserwowana temperatura 73.125°C,
minimum MemAvailable 78 629 636 KiB. Żaden limit nie przerwał pomiaru.
To próbki okresowe, nie gwarancja braku krótkich pików między próbkami.
Pulpit i aplikacje użytkownika mogły pracować w tle. Nie wymuszano cold cache,
governor ani wyłączania swap; nie jest to odizolowany fizyczny host testowy.

Oryginalne `COMPLETE`, `RECHECKED`, `ORDER.csv` oraz `monitor.csv` zachowano.
Publikacja nadal wymaga przeglądu zakresu i licencji; ten wynik ich nie zatwierdza.
