# P2 — generacje, przyrosty i ranking po restartach

Lokalny etap laboratoryjny, Rust1.85.0/Linux. Nie opublikowano kodu i nie
zmieniono licencji. P1/O8/T9 pozostawiono bez zmian. Protokół: P2-PROTOCOL.md.

## Wynik

**1M i10M: zapis, cztery trwałe operacje, replay w nowym procesie,
checkpoint i ponowne otwarcie — PASS w tej kampanii.** Po obu odtworzeniach
każdy slot porównano bitowo z niezależnie regenerowanym oczekiwanym rekordem.
Usunięty ID nie wraca do wyszukiwania; nowy rekord ma nowy stabilny ID.

Trzy pełne zapytania (zaktualizowany, usunięty, dodany rekord) przed restartem,
po replay oraz po checkpointcie mają identyczne hashe całych wektorów
`ID + score_bits`. Każdy wektor adaptacyjnego czytnika porównano również
bitowo ze ścieżką bazową. Razem99 mln porównań par score, bez rozbieżności.
To test trwałości numerycznego rankingu, nie trafności językowej lub AI.

| Pomiar, jeden przebieg |1M|10M|
|---|---:|---:|
| Generowanie + pierwszy trwały snapshot |3,400s|29,452s|
| Cztery operacje z zatwierdzeniem/fsync, bez czasu otwarcia |82,227ms|83,436ms|
| Otwórz + zweryfikuj + replay |1,545s|13,184s|
| Checkpoint, bez czasu otwarcia |1,272s|10,976s|
| Otwórz checkpoint + zweryfikuj |1,392s|13,097s|
| HWM całej próby replay z kopią do rankingu |2 285 056KiB|22 825 324KiB|

Nie wyliczamy percentyli dla tych pojedynczych czasów. Pomiar replay obejmuje
pełne hashowanie i dekodowanie snapshotu, nie tylko cztery ramki WAL.
Pełna komenda verify trwa dłużej: dodatkowo regeneruje oczekiwane rekordy,
buduje drugi bank do rankingu i wykonuje po dwa skany dla każdego pytania.
Mały RSS na końcu logu jest już po zwolnieniu banku, nie kosztem rezydentnego
Oceanu. HWM uwzględnia te pomocnicze kopie.

## Implementacja i granice zaufania

- Snapshot immutable, journal o sekwencji globalnej i łańcuchu SHA256,
  osobny zaufany CURRENT wybiera generację i zatwierdzony prefiks.
- Insert/update/delete, tombstones, kontrola rewizji, limit4096 ramek między
  checkpointami i10 001 024 slotów. Nie ma automatycznego GC starych generacji.
- Jeden writer: kernelowy flock na katalogu danych i katalogu anchora.
  Locki są advisory; obcy proces ignorujący protokół nie jest powstrzymywany.
- ACK dopiero po fsync WAL, publikacji anchora i fsync jego katalogu.
  Niejednoznaczny błąd I/O zatruwa sesję: trzeba ją otworzyć ponownie.
- Niepublikowany ogon WAL nie jest automatycznie zatwierdzany. Osierocony
  snapshot nie staje się aktywny dlatego, że ma największy numer.

Checksum nie jest autoryzacją. Właściciel musi kontrolować oba katalogi.
Opcjonalny zewnętrzny pin anchora wykrywa jego zmianę/rollback; kampania duża
ufa lokalnemu CURRENT. Testy małe sprawdzają także zewnętrzny pin.
Brak ochrony przed administratorem i wrogą podmianą ścieżek w katalogu.

Rekord numeryczny nadal1152B. Slot snapshotu ma dodatkowy bajt live/tombstone;
plik to1153×liczba_slotów+72B. Po delete+insert: N żywych rekordów, N+1 slotów.
WAL z czterema operacjami:4980B, po checkpointcie48B. To nie kompresja4×.

## Testy błędów

Osiem testów integracyjnych Rust przeszło (`p2-tests-hardened.log`):
pięć storage, dwa forged, jeden wieloscenariuszowy crash. Crash obejmuje
**12 rzeczywistych SIGKILL** własnego procesu potomnego: pięć punktów commit
i siedem checkpoint. Sprawdzono konkurencyjnego writera przed zabiciem,
otwarcie w nowym procesie, pełny ranking oraz bezpieczną próbę ponowienia.
Dokładne punkty: `p2-crash-evidence-final.txt`.
Te12 prób SIGKILL używa banku128 rekordów; nie są12 awariami banku10M.
Po zamrożonej kampanii dodano i uruchomiono trzy dodatkowe testy graniczne:
pełny WAL4096 ramek, wznowienie po checkpointcie, współdzielony katalog
anchora i odmowa nadpisania zmienionego CURRENT. Łącznie11 testów PASS
w `p2-tests-supplementary.log`, bez zmiany mierzonego kodu produkcyjnego.

Dodatkowo każdy prefiks małego zatwierdzonego WAL, każde przekłamanie jednego
bajtu WAL/snapshotu/anchora, błędne ID/revizje/limity, niekanoniczne tombstones,
podmieniony i ponownie zahashowany payload, poprawnie zahashowane niedozwolone
operacje, symlinki, brak RAM, zatruty writer i osierocone generacje.
Nie jest to fuzzing wszystkich stanów ani dowód odporności na utratę zasilania.

## Środowisko, dowody i reprodukcja

Ten sam PC AMD Ryzen AI9 HX370/24 logiczne CPU. Przebieg w izolowanej sieci
`bwrap --unshare-net`. W198 próbkach monitora: temperatura max77,375°C,
minimalne MemAvailable68 259 312KiB. Limity:85°C,8GiB wolnego RAM,
20GiB rezerwy dysku,900s na komendę. Nie zmieniano ustawień systemowych.

`persistence-p2/` zawiera surowe logi, monitor, snapshoty, WAL i anchory.
`P2-INPUTS.sha256`, `P2-RUNTIME-BINARIES.sha256`, `p2-environment.txt` wiążą
implementację z pomiarem. Manifest wejść sporządzono po uruchomieniu kampanii,
gdy kod i binaria nie były zmieniane, i sprawdzono ponownie po zakończeniu.

```sh
cd p2-candidate
cargo test --offline
cargo build --offline --release --bins
cd ..
# W nowym katalogu roboczym, bez istniejącego persistence-p2:
# /pełna/ścieżka/p2-candidate/target/release/p2_campaign
```

To jawny format syntetycznych danych publicznego czytnika. **Nie został
podłączony zamiast szyfrowanej pamięci osobistej, do rozmów lub P2P.**
Nie dowodzi fizycznego sprzężenia z odświeżaniem DRAM. Wyłącznie Linux;
jedyny unsafe w module to krótki opisany FFI flock, nie parser danych.
