# M1 — bezpieczna próba mmap, protokół przed pomiarem

Linux / Rust 1.85, wyłącznie syntetyczne snapshoty P2 po checkpointcie.
Nie mapujemy bezpośrednio pliku, który inny proces mógłby skrócić lub zmienić.
MAP_PRIVATE samo w sobie nie daje takiej ochrony. Kopiujemy ograniczony rozmiarem
plik do memfd, nakładamy kernelowe seals WRITE/GROW/SHRINK/SEAL, a dopiero potem
tworzymy odczytowe mapowanie i sprawdzamy całą strukturę oraz pin snapshotu.
Zmiana źródła podczas kopiowania powinna zostać wykryta przez pin snapshotu.

To **copy → seal → mmap → validate**, nie zero-copy z dysku ani prywatny sejf.
Cena kopii, hasha i pamięci memfd należy do wyniku. Strony mogą być swapowane;
nie obiecujemy ochrony przed administratorem ani cold boot. Deskryptor nie jest
eksportowany. API zwraca własny rekord po sprawdzeniu indeksu, bez rzutowania
bajtów na struktury Rust. Snapshot z niewykonanym WAL jest odrzucany.

Testy: uszkodzenia, generacje, pin, WAL, write/truncate po seals, zmiana źródła,
granice i lifetime po zamknięciu deskryptora. Porównanie 1M/10M z dekoderem P2:
identyczność każdego slotu i ID; osobno koszt mapowania+kopii+walidacji oraz
jawnego dekodowania i porównania. Mierzyć CPU/faults/RSS. Nie resetować cache
hosta i nie nazywać nowego procesu zimnym cache.
