# C1 — kontrola liczby workerów, zamrożony T9

Bez zmiany czytnika ani progów T9. Macierz: 1M/10M, 1/12/24 workerów,
trzy nowe seedy 41119/51131/61141, sześć cykli siedmiu klas w komórce.
18 komórek, 756 operacji E2E (648 pełnych skanów i 108 pustych zapytań).
Każde zapytanie przy danym rozmiarze/seedzie identyczne między workerami.
Kolejność rozmiarów i workerów przeplatana, nie uruchamiać komórek równolegle.

To diagnostyka skalowania wątków, **nie** powtórzenie pełnego T9 N=100 ani
zamknięcie p99.9. Tylko sześć próbek na klasę/komórkę: publikować medianę
i zakres, nie obietnicę stabilnego ogona. Identyczne listy query, corpus SHA,
decyzje i top10 mają się zgadzać między 1/12/24. Bazowy bit-check i scalar
oracle pozostają w niezmienionym T9. CPU/faults/context-switches z getrusage
obejmują cały proces (generator, walidację i ranking), nie sam kernel.

RAM min8GiB, CPU stop85°C, limit1200s/komórkę. Wszystkie przebiegi zachować,
także wolniejsze. Bez resetowania cache, modyfikacji systemu i publikacji.
Ta próba nie mierzy osobno hot/cold set, fizycznego refresh ani scheduler trace.
