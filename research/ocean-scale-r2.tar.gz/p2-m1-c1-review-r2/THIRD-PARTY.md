# Exact third-party inventory

Twelve locked registry package versions across five workspaces. Both libc versions
are intentionally retained to reproduce the measured locked builds. GEL licensing
does not supersede dependency licenses. No dependency download is needed.

| Package | Version | Declared license | Registry package SHA256 |
|---|---|---|---|
| block-buffer | 0.10.4 | MIT OR Apache-2.0 | `3078c7629b62d3f0439517fa394996acacc5cbc91c5a20d8c658e77abd503a71` |
| cfg-if | 1.0.5 | MIT OR Apache-2.0 | `4e7648175b45a9a48536d676f68d918270699102aa8dab5496df06904c914600` |
| cpufeatures | 0.2.17 | MIT OR Apache-2.0 | `59ed5838eebb26a2bb2e58f6d5b5316989ae9d08bab10e0e6d103e656d1b0280` |
| crypto-common | 0.1.7 | MIT OR Apache-2.0 | `78c8292055d1c1df0cce5d180393dc8cce0abec0a7102adb6c7b1eef6016d60a` |
| digest | 0.10.7 | MIT OR Apache-2.0 | `9ed9a281f7bc9b7576e61468ba615a66a5c8cfdff42420a70aa82701a3b1e292` |
| generic-array | 0.14.7 | MIT | `85649ca51fd72272d7821adaf274ad91c288277713d9c18820d8499a7ff69e9a` |
| libc | 0.2.186 | MIT OR Apache-2.0 | `68ab91017fe16c622486840e4c83c9a37afeff978bd239b5293d61ece587de66` |
| libc | 0.2.189 | MIT OR Apache-2.0 | `3eaf3ede3fee6db1a4c2ee091bf8a8b4dccdc6d17f656fb07896ee72867612f2` |
| memmap2 | 0.9.11 | MIT OR Apache-2.0 | `d1219ed1b7f229ee7104d281dd01d6802fe28bb6e95d292942c4daacdeb798c0` |
| sha2 | 0.10.9 | MIT OR Apache-2.0 | `a7507d819769d01a365ab707794a4084392c824f54a7a6a7862f8c3d0892b283` |
| typenum | 1.20.1 | MIT OR Apache-2.0 | `b6f5e870be6c3b371b77fe0ee0bafb859fa4964b4404c27de1d380043c4dda20` |
| version_check | 0.9.5 | MIT/Apache-2.0 | `0b928f33d975fc6ad9f86c8f283853ad26bdd5b10b7f1542aa2fa15e2289105a` |

Each full package, upstream copyright notices and license texts are preserved in
`source/vendor/NAME-VERSION/`. `generic-array` has `LICENSE`; other packages have
`LICENSE-MIT` and `LICENSE-APACHE` (typenum additionally includes `LICENSE`).
Cargo verifies `.cargo-checksum.json`; the package-wide source manifest covers
all vendored files. The package checksums above are registry archive checksums,
not hashes of extracted directories.

First-party code is covered by the unchanged root LICENSE. This includes the
copied public reader and the proposed laboratory source modules. Source code,
not just timings, is deliberately part of this review candidate. Publication
requires approval of this disclosure scope. This inventory is not a legal opinion.

