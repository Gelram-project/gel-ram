#![deny(unsafe_code)]
#[allow(unsafe_code)]
mod usage {
    pub fn children() -> std::io::Result<libc::rusage> {
        let mut v = std::mem::MaybeUninit::<libc::rusage>::uninit();
        // SAFETY: valid writable rusage allocation; only initialized on success.
        let rc = unsafe { libc::getrusage(libc::RUSAGE_CHILDREN, v.as_mut_ptr()) };
        if rc != 0 {
            return Err(std::io::Error::last_os_error());
        }
        // SAFETY: successful getrusage initialized the output struct.
        Ok(unsafe { v.assume_init() })
    }
}
use std::{
    fs::{self, File, OpenOptions},
    io::Write,
    path::Path,
    process::{Child, Command, Stdio},
    time::{Duration, Instant},
};
type Result<T> = std::result::Result<T, Box<dyn std::error::Error>>;
struct Owned(Child);
impl Drop for Owned {
    fn drop(&mut self) {
        let _ = self.0.kill();
        let _ = self.0.wait();
    }
}
fn create(p: &Path) -> std::io::Result<File> {
    OpenOptions::new().create_new(true).write(true).open(p)
}
fn resources() -> Result<(u64, u64)> {
    let m = fs::read_to_string("/proc/meminfo")?
        .lines()
        .find_map(|l| l.strip_prefix("MemAvailable:"))
        .and_then(|s| s.split_whitespace().next())
        .ok_or("RAM")?
        .parse::<u64>()?;
    let mut t = None;
    for e in fs::read_dir("/sys/class/hwmon")? {
        let p = e?.path();
        if fs::read_to_string(p.join("name"))
            .unwrap_or_default()
            .trim()
            == "k10temp"
        {
            t = Some(
                fs::read_to_string(p.join("temp1_input"))?
                    .trim()
                    .parse::<u64>()?,
            );
        }
    }
    let t = t.ok_or("CPU sensor")?;
    if m < 8 * 1024 * 1024 || t >= 85000 {
        return Err("resource stop".into());
    }
    Ok((m, t))
}
fn us(t: libc::timeval) -> i64 {
    t.tv_sec * 1_000_000 + t.tv_usec
}
fn main() -> Result<()> {
    let cwd = std::env::current_dir()?;
    let root = cwd.join("contention-c1");
    fs::create_dir(&root)?;
    let bin = cwd.join("t9-candidate/target/release/search_tail_t9");
    let mut monitor = create(&root.join("monitor.csv"))?;
    writeln!(monitor, "run,elapsed_ms,available_KiB,cpu_mC")?;
    let mut plan = create(&root.join("ORDER.csv"))?;
    writeln!(plan, "order,n,seed,workers,cycles")?;
    let mut order = Vec::new();
    for (si, seed) in [41119, 51131, 61141].iter().enumerate() {
        let sizes = if si % 2 == 0 {
            [1_000_000, 10_000_000]
        } else {
            [10_000_000, 1_000_000]
        };
        for (ni, n) in sizes.iter().enumerate() {
            let mut workers = [1, 12, 24];
            workers.rotate_left(si);
            if ni == 1 {
                workers.reverse();
            }
            for w in workers {
                order.push((*n, *seed, w));
            }
        }
    }
    for (i, (n, s, w)) in order.iter().enumerate() {
        writeln!(plan, "{i},{n},{s},{w},6")?;
    }
    plan.sync_all()?;
    for (n, seed, w) in order {
        resources()?;
        let name = format!("n{n}-s{seed}-w{w}");
        let before = usage::children()?;
        let start = Instant::now();
        let mut child = Owned(
            Command::new(&bin)
                .args([n.to_string(), w.to_string(), seed.to_string(), "6".into()])
                .arg(root.join(&name))
                .stdout(Stdio::from(create(&root.join(format!("{name}.log")))?))
                .stderr(Stdio::from(create(&root.join(format!("{name}.stderr")))?))
                .spawn()?,
        );
        loop {
            let (m, t) = resources()?;
            writeln!(monitor, "{name},{},{m},{t}", start.elapsed().as_millis())?;
            monitor.flush()?;
            if let Some(status) = child.0.try_wait()? {
                if !status.success() {
                    return Err(format!("{name}: {status}").into());
                }
                break;
            }
            if start.elapsed() > Duration::from_secs(1200) {
                return Err("timeout".into());
            }
            std::thread::sleep(Duration::from_millis(500));
        }
        let after = usage::children()?;
        let mut f = create(&root.join(format!("{name}.resources")))?;
        writeln!(f,"WALL_NS={}\nUSER_US={}\nSYSTEM_US={}\nMINFLT={}\nMAJFLT={}\nNVCSW={}\nNIVCSW={}\nSCOPE=WHOLE_PROCESS_NOT_KERNEL",
            start.elapsed().as_nanos(),us(after.ru_utime)-us(before.ru_utime),us(after.ru_stime)-us(before.ru_stime),
            after.ru_minflt-before.ru_minflt,after.ru_majflt-before.ru_majflt,after.ru_nvcsw-before.ru_nvcsw,after.ru_nivcsw-before.ru_nivcsw)?;
        f.sync_all()?;
        println!("{name}: PASS");
    }
    monitor.sync_all()?;
    let mut done = create(&root.join("COMPLETE"))?;
    writeln!(done, "C1_COLLECTION_COMPLETE_REQUIRES_CROSSCHECK")?;
    done.sync_all()?;
    Ok(())
}
