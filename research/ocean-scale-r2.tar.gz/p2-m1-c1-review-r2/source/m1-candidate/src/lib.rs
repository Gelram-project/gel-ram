#![deny(unsafe_code)]
#[allow(unsafe_code)]
mod sealed;
use gel_p2_lab::{decode, require, Anchor, Pin, Result, MAX_SLOTS, WIDTH};
use memmap2::Mmap;
use o3::Record;
use sha2::{Digest, Sha256};
use std::{
    fs::{self, File},
    path::Path,
};

pub struct SnapshotMap {
    map: Mmap,
    count: usize,
}
fn num(b: &[u8]) -> u64 {
    u64::from_le_bytes(b.try_into().unwrap())
}
impl SnapshotMap {
    pub fn open(path: &Path, anchor: Anchor, budget: u64) -> Result<Self> {
        Anchor::parse(&anchor.bytes(), None)?;
        require(
            anchor.frames == 0 && anchor.base_sequence == anchor.sequence,
            "checkpoint required: mapped snapshot does not replay WAL",
        )?;
        require(fs::symlink_metadata(path)?.is_file(), "not regular source")?;
        let file = File::open(path)?;
        let len = file.metadata()?.len();
        require(
            file.metadata()?.is_file()
                && len >= 72
                && len <= budget
                && len <= MAX_SLOTS as u64 * (WIDTH as u64 + 1) + 72,
            "mapping size/budget",
        )?;
        let map = sealed::copy_and_map(file, len)?;
        let count = Self::validate(&map, anchor)?;
        Ok(Self { map, count })
    }
    fn validate(b: &[u8], a: Anchor) -> Result<usize> {
        require(b.len() >= 72, "short snapshot")?;
        require(
            &b[..8] == b"GELP2S01"
                && num(&b[8..16]) == a.generation
                && num(&b[16..24]) == a.base_sequence
                && num(&b[32..40]) == WIDTH as u64,
            "snapshot header",
        )?;
        let count = num(&b[24..32]);
        require(
            count <= MAX_SLOTS as u64 && b.len() as u64 == count * (WIDTH as u64 + 1) + 72,
            "snapshot length",
        )?;
        let end = b.len() - 32;
        require(
            Pin::from(Sha256::digest(&b[..end])) == a.snapshot && b[end..] == a.snapshot,
            "snapshot pin",
        )?;
        for row in b[40..end].chunks_exact(WIDTH + 1) {
            require(
                row[0] <= 1 && (row[0] == 1 || row[1..].iter().all(|&x| x == 0)),
                "slot encoding",
            )?;
        }
        Ok(count as usize)
    }
    pub fn len(&self) -> usize {
        self.count
    }
    pub fn is_empty(&self) -> bool {
        self.count == 0
    }
    pub fn mapped_bytes(&self) -> usize {
        self.map.len()
    }
    pub fn record(&self, id: usize) -> Result<Option<Record>> {
        require(id < self.count, "slot out of bounds")?;
        let start = 40 + id * (WIDTH + 1);
        let row = &self.map[start..start + WIDTH + 1];
        Ok(if row[0] == 0 {
            None
        } else {
            Some(decode(row[1..].try_into().unwrap()))
        })
    }
}
