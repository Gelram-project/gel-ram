//! Linux-only private immutable backing. No mutable mapping or FD is exposed.
use gel_p2_lab::{require, Result};
use memmap2::{Mmap, MmapOptions};
use std::{
    fs::File,
    io::{Read, Seek, SeekFrom, Write},
    os::fd::{AsRawFd, FromRawFd},
};
#[cfg(not(target_os = "linux"))]
compile_error!("M1 currently supports Linux only");
const SEALS: libc::c_int =
    libc::F_SEAL_WRITE | libc::F_SEAL_GROW | libc::F_SEAL_SHRINK | libc::F_SEAL_SEAL;
fn backing(mut source: File, len: u64) -> Result<File> {
    // SAFETY: static NUL-terminated name, valid scalar flags, no retained pointer.
    let fd = unsafe {
        libc::memfd_create(
            b"gel-m1\0".as_ptr().cast(),
            libc::MFD_CLOEXEC | libc::MFD_ALLOW_SEALING,
        )
    };
    if fd < 0 {
        return Err(std::io::Error::last_os_error().into());
    }
    // SAFETY: successful memfd_create returned a new owned FD, consumed once here.
    let mut target = unsafe { File::from_raw_fd(fd) };
    let copied = std::io::copy(&mut (&mut source).take(len), &mut target)?;
    require(copied == len, "source shortened during copy")?;
    let mut extra = [0];
    require(source.read(&mut extra)? == 0, "source grew during copy")?;
    target.flush()?;
    // SAFETY: owned FD; this fcntl command takes an integer, no memory pointers.
    let rc = unsafe { libc::fcntl(target.as_raw_fd(), libc::F_ADD_SEALS, SEALS) };
    if rc < 0 {
        return Err(std::io::Error::last_os_error().into());
    }
    // SAFETY: integer FD and command without additional arguments.
    let actual = unsafe { libc::fcntl(target.as_raw_fd(), libc::F_GET_SEALS) };
    require(actual >= 0 && actual & SEALS == SEALS, "seals not applied")?;
    target.seek(SeekFrom::Start(0))?;
    Ok(target)
}
pub fn copy_and_map(source: File, len: u64) -> Result<Mmap> {
    let file = backing(source, len)?;
    // SAFETY: private memfd sealed against writes and resizing before mapping;
    // no writable mapping exists, FD is not exported, seals cannot be removed.
    // Mapping lifetime is independent of File; the kernel retains its pages.
    Ok(unsafe { MmapOptions::new().len(usize::try_from(len)?).map(&file)? })
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn seals_reject_write_shrink_grow_and_map_outlives_fd() {
        let mut f = backing(
            File::open("/proc/version").unwrap(),
            std::fs::read("/proc/version").unwrap().len() as u64,
        )
        .unwrap();
        assert!(f.write_all(b"X").is_err());
        assert!(f.set_len(0).is_err());
        assert!(f.set_len(f.metadata().unwrap().len() + 1).is_err());
        // SAFETY: same immutable sealed backing invariant as production helper.
        let map = unsafe { MmapOptions::new().map(&f).unwrap() };
        drop(f);
        assert!(map.starts_with(b"Linux version"));
    }
}
