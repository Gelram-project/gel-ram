//! Additional structural checks after the frozen large M1 run.
use gel_m1_lab::SnapshotMap;
use gel_p2_lab::*;
use o3::Record;
use std::{fs,path::PathBuf,sync::atomic::{AtomicU64,Ordering}};
struct Temp(PathBuf);
impl Temp {
    fn new()->Self{static N:AtomicU64=AtomicU64::new(0);for _ in 0..1000{
        let p=std::env::temp_dir().join(format!("gel-m1-forged-{}-{}",std::process::id(),N.fetch_add(1,Ordering::Relaxed)));
        if fs::create_dir(&p).is_ok(){fs::create_dir(p.join("data")).unwrap();fs::create_dir(p.join("trust")).unwrap();return Self(p);}
    }panic!("temp");}
}
impl Drop for Temp{fn drop(&mut self){let _=fs::remove_dir_all(&self.0);}}
#[test]
fn matching_hash_cannot_make_a_noncanonical_slot_valid(){
    let t=Temp::new();let w=Writer::initialize(&t.0.join("data"),&t.0.join("trust"),Table::new(vec![Record::new([9;1024],&[true;1024])]).unwrap(),&mut |_|Ok(())).unwrap();
    let a=w.anchor();drop(w);let path=t.0.join("data/generation-00000000000000000001.snapshot");
    let original=fs::read(&path).unwrap();
    for flag in [0u8,2,255]{
        let mut b=original.clone();b[40]=flag;
        let end=b.len()-32;let pin=digest(&b[..end]);b[end..].copy_from_slice(&pin);
        fs::write(&path,&b).unwrap();
        assert!(SnapshotMap::open(&path,Anchor{snapshot:pin,..a},100000).is_err());
    }
}
