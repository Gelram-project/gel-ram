use gel_m1_lab::SnapshotMap;
use gel_p2_lab::*;
use o3::Record;
use std::{
    fs,
    path::PathBuf,
    sync::atomic::{AtomicU64, Ordering},
};
struct Temp(PathBuf);
impl Temp {
    fn new() -> Self {
        static N: AtomicU64 = AtomicU64::new(0);
        for _ in 0..1000 {
            let p = std::env::temp_dir().join(format!(
                "gel-m1-{}-{}",
                std::process::id(),
                N.fetch_add(1, Ordering::Relaxed)
            ));
            if fs::create_dir(&p).is_ok() {
                fs::create_dir(p.join("data")).unwrap();
                fs::create_dir(p.join("trust")).unwrap();
                return Self(p);
            }
        }
        panic!("temp allocation");
    }
}
impl Drop for Temp {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.0);
    }
}
fn rec() -> Record {
    Record::new([193; 1024], &std::array::from_fn(|j| j % 7 != 0))
}
#[test]
fn mapped_snapshot_survives_source_change_and_preserves_tombstones() {
    let t = Temp::new();
    let mut w = Writer::initialize(
        &t.0.join("data"),
        &t.0.join("trust"),
        Table::new(vec![rec(), rec()]).unwrap(),
        &mut |_| Ok(()),
    )
    .unwrap();
    w.commit(0, Operation::Delete { slot: 1 }, &mut |_| Ok(()))
        .unwrap();
    let old = w.anchor();
    assert!(SnapshotMap::open(
        &t.0.join("data/generation-00000000000000000001.snapshot"),
        old,
        100000
    )
    .is_err());
    let a = w.checkpoint(&mut |_| Ok(())).unwrap();
    drop(w);
    let p = t.0.join("data/generation-00000000000000000002.snapshot");
    let mapped = SnapshotMap::open(&p, a, 100000).unwrap();
    assert_eq!(mapped.len(), 2);
    assert!(!mapped.is_empty());
    assert_eq!(encode(&mapped.record(0).unwrap().unwrap()), encode(&rec()));
    assert!(mapped.record(1).unwrap().is_none());
    assert!(mapped.record(2).is_err());
    assert!(mapped.record(usize::MAX).is_err());
    fs::write(&p, b"replaced test input").unwrap();
    assert_eq!(encode(&mapped.record(0).unwrap().unwrap()), encode(&rec()));
    assert!(SnapshotMap::open(&p, a, 100000).is_err());
}
#[test]
fn rejects_corruption_wrong_pin_size_generation_and_budget() {
    let t = Temp::new();
    let w = Writer::initialize(
        &t.0.join("data"),
        &t.0.join("trust"),
        Table::new(vec![rec()]).unwrap(),
        &mut |_| Ok(()),
    )
    .unwrap();
    let a = w.anchor();
    drop(w);
    let p = t.0.join("data/generation-00000000000000000001.snapshot");
    let bytes = fs::read(&p).unwrap();
    assert!(SnapshotMap::open(&p, a, 1).is_err());
    assert!(SnapshotMap::open(
        &p,
        Anchor {
            snapshot: [0; 32],
            ..a
        },
        100000
    )
    .is_err());
    assert!(SnapshotMap::open(&p, Anchor { generation: 2, ..a }, 100000).is_err());
    for i in 0..bytes.len() {
        let mut bad = bytes.clone();
        bad[i] ^= 1;
        fs::write(&p, &bad).unwrap();
        assert!(SnapshotMap::open(&p, a, 100000).is_err(), "byte {i}");
    }
    for cut in [0, 39, 40, 71, bytes.len() - 1] {
        fs::write(&p, &bytes[..cut]).unwrap();
        assert!(SnapshotMap::open(&p, a, 100000).is_err());
    }
    fs::write(&p, &bytes).unwrap();
    assert!(SnapshotMap::open(&p, a, 100000).is_ok());
}
#[test]
fn empty_checkpoint_is_valid() {
    let t = Temp::new();
    let w = Writer::initialize(
        &t.0.join("data"),
        &t.0.join("trust"),
        Table::new(vec![]).unwrap(),
        &mut |_| Ok(()),
    )
    .unwrap();
    let map = SnapshotMap::open(
        &t.0.join("data/generation-00000000000000000001.snapshot"),
        w.anchor(),
        100,
    )
    .unwrap();
    assert!(map.is_empty());
    assert_eq!(map.mapped_bytes(), 72);
    assert!(map.record(0).is_err());
}
