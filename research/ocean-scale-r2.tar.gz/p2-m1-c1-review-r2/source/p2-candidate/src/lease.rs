//! Linux advisory writer exclusion. The lock file must never be unlinked.
//! Owner-controlled parent directory; no claim against hostile path replacement.
use std::{
    fs::{File, OpenOptions},
    os::{fd::AsRawFd, unix::fs::OpenOptionsExt},
    path::Path,
};
#[cfg(not(target_os = "linux"))]
compile_error!("P2 lease currently supports Linux only");
extern "C" {
    fn flock(fd: std::ffi::c_int, operation: std::ffi::c_int) -> std::ffi::c_int;
}
pub struct Lease {
    _file: File,
}
impl Lease {
    pub fn acquire(path: &Path) -> std::io::Result<Self> {
        if path.symlink_metadata().is_ok_and(|m| !m.is_file()) {
            return Err(std::io::Error::other("nonregular lock"));
        }
        let file = OpenOptions::new()
            .create(true)
            .truncate(false)
            .read(true)
            .write(true)
            .mode(0o600)
            .open(path)?;
        // SAFETY: flock accepts an integer FD, borrows no memory and retains no
        // Rust pointer. `file` remains open throughout the call and guard lifetime.
        // LOCK_EX=2, LOCK_NB=4 from Linux sys/file.h. Closing this owned File releases
        // its lock, including when the process is killed. Rust descriptors are CLOEXEC.
        let result = unsafe { flock(file.as_raw_fd(), 2 | 4) };
        if result != 0 {
            return Err(std::io::Error::last_os_error());
        }
        Ok(Self { _file: file })
    }
}
