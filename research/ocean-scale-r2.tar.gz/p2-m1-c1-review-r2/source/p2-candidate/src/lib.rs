#![deny(unsafe_code)]
#[allow(unsafe_code)]
mod lease;
use o3::Record;
use sha2::{Digest, Sha256};
use std::{
    fs::{self, File, OpenOptions},
    io::{BufReader, BufWriter, Read, Seek, SeekFrom, Write},
    os::unix::fs::OpenOptionsExt,
    path::{Path, PathBuf},
};
pub type Result<T> = std::result::Result<T, Box<dyn std::error::Error>>;
pub type Pin = [u8; 32];
pub const WIDTH: usize = 1152;
pub const FRAME: usize = 8 + 32 + 1 + 8 + WIDTH + 32;
pub const WAL_HEAD: usize = 48;
// A 10M live-record bank may retain tombstoned IDs and append replacements.
pub const MAX_SLOTS: usize = 10_001_024;
pub const MAX_FRAMES: u64 = 4096;
const SNAP_MAGIC: &[u8; 8] = b"GELP2S01";
const WAL_MAGIC: &[u8; 8] = b"GELP2W01";
const HEAD_MAGIC: &[u8; 8] = b"GELP2A01";
pub fn require(ok: bool, msg: &str) -> Result<()> {
    if ok {
        Ok(())
    } else {
        Err(msg.into())
    }
}
pub fn digest(bytes: &[u8]) -> Pin {
    Sha256::digest(bytes).into()
}
pub fn hex(pin: Pin) -> String {
    pin.iter().map(|b| format!("{b:02x}")).collect()
}
pub fn encode(r: &Record) -> [u8; WIDTH] {
    let mut b = [0; WIDTH];
    b[..1024].copy_from_slice(r.phase());
    for j in 0..1024 {
        if r.active(j).unwrap() {
            b[1024 + j / 8] |= 1 << (j % 8);
        }
    }
    b
}
pub fn decode(b: &[u8; WIDTH]) -> Record {
    Record::new(
        b[..1024].try_into().unwrap(),
        &std::array::from_fn(|j| b[1024 + j / 8] & (1 << (j % 8)) != 0),
    )
}
fn num(b: &[u8]) -> u64 {
    u64::from_le_bytes(b.try_into().unwrap())
}
fn new_file(p: &Path) -> Result<File> {
    Ok(OpenOptions::new()
        .create_new(true)
        .write(true)
        .mode(0o600)
        .open(p)?)
}
fn regular(p: &Path) -> Result<File> {
    require(fs::symlink_metadata(p)?.is_file(), "not regular file")?;
    let f = File::open(p)?;
    require(f.metadata()?.is_file(), "not regular descriptor")?;
    Ok(f)
}
fn paths(root: &Path, g: u64) -> (PathBuf, PathBuf) {
    (
        root.join(format!("generation-{g:020}.snapshot")),
        root.join(format!("generation-{g:020}.wal")),
    )
}
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Anchor {
    pub generation: u64,
    pub sequence: u64,
    pub base_sequence: u64,
    pub snapshot: Pin,
    pub tail: Pin,
    pub frames: u64,
}
impl Anchor {
    pub fn bytes(self) -> [u8; 136] {
        let mut b = [0; 136];
        b[..8].copy_from_slice(HEAD_MAGIC);
        b[8..16].copy_from_slice(&self.generation.to_le_bytes());
        b[16..24].copy_from_slice(&self.sequence.to_le_bytes());
        b[24..32].copy_from_slice(&self.base_sequence.to_le_bytes());
        b[32..64].copy_from_slice(&self.snapshot);
        b[64..96].copy_from_slice(&self.tail);
        b[96..104].copy_from_slice(&self.frames.to_le_bytes());
        let pin = digest(&b[..104]);
        b[104..].copy_from_slice(&pin);
        b
    }
    pub fn parse(b: &[u8], expected: Option<Pin>) -> Result<Self> {
        require(b.len() == 136, "anchor length")?;
        require(
            expected.is_none_or(|p| digest(b) == p),
            "external anchor pin",
        )?;
        require(
            &b[..8] == HEAD_MAGIC && digest(&b[..104]) == b[104..],
            "anchor checksum",
        )?;
        let a = Self {
            generation: num(&b[8..16]),
            sequence: num(&b[16..24]),
            base_sequence: num(&b[24..32]),
            snapshot: b[32..64].try_into().unwrap(),
            tail: b[64..96].try_into().unwrap(),
            frames: num(&b[96..104]),
        };
        require(
            a.generation > 0
                && a.frames <= MAX_FRAMES
                && a.base_sequence.checked_add(a.frames) == Some(a.sequence),
            "anchor bounds",
        )?;
        Ok(a)
    }
    pub fn pin(self) -> Pin {
        digest(&self.bytes())
    }
}
pub fn trusted_anchor(trust: &Path, expected: Option<Pin>) -> Result<Anchor> {
    let mut f = regular(&trust.join("CURRENT"))?;
    require(f.metadata()?.len() == 136, "anchor size")?;
    let mut b = [0; 136];
    f.read_exact(&mut b)?;
    Anchor::parse(&b, expected)
}
#[derive(Clone)]
pub struct Table {
    pub rows: Vec<Option<Record>>,
    pub sequence: u64,
}
impl Table {
    pub fn new(records: Vec<Record>) -> Result<Self> {
        require(records.len() <= MAX_SLOTS, "slot limit")?;
        Ok(Self {
            rows: records.into_iter().map(Some).collect(),
            sequence: 0,
        })
    }
    fn validate(&self, op: &Operation) -> Result<()> {
        match op {
            Operation::Insert { slot, .. } => {
                require(*slot == self.rows.len() && *slot < MAX_SLOTS, "insert ID")
            }
            Operation::Update { slot, .. } | Operation::Delete { slot } => require(
                self.rows.get(*slot).is_some_and(Option::is_some),
                "missing/deleted ID",
            ),
        }
    }
    fn apply(&mut self, op: Operation) -> Result<()> {
        self.validate(&op)?;
        let next = self.sequence.checked_add(1).ok_or("sequence overflow")?;
        match op {
            Operation::Insert { record, .. } => self.rows.push(Some(record)),
            Operation::Update { slot, record } => self.rows[slot] = Some(record),
            Operation::Delete { slot } => self.rows[slot] = None,
        };
        self.sequence = next;
        Ok(())
    }
}
#[derive(Clone)]
pub enum Operation {
    Insert { slot: usize, record: Record },
    Update { slot: usize, record: Record },
    Delete { slot: usize },
}
impl Operation {
    fn payload(&self) -> (u8, usize, [u8; WIDTH]) {
        match self {
            Self::Insert { slot, record } => (1, *slot, encode(record)),
            Self::Update { slot, record } => (2, *slot, encode(record)),
            Self::Delete { slot } => (3, *slot, [0; WIDTH]),
        }
    }
}
fn wal_header(g: u64, p: Pin) -> [u8; WAL_HEAD] {
    let mut h = [0; WAL_HEAD];
    h[..8].copy_from_slice(WAL_MAGIC);
    h[8..16].copy_from_slice(&g.to_le_bytes());
    h[16..].copy_from_slice(&p);
    h
}
fn frame_hash(g: u64, b: &[u8]) -> Pin {
    let mut h = Sha256::new();
    h.update(b"GEL-P2-FRAME");
    h.update(g.to_le_bytes());
    h.update(b);
    h.finalize().into()
}
fn frame(a: Anchor, op: &Operation) -> Result<[u8; FRAME]> {
    let mut b = [0; FRAME];
    b[..8].copy_from_slice(
        &a.sequence
            .checked_add(1)
            .ok_or("sequence overflow")?
            .to_le_bytes(),
    );
    b[8..40].copy_from_slice(&a.tail);
    let (kind, id, payload) = op.payload();
    b[40] = kind;
    b[41..49].copy_from_slice(&(id as u64).to_le_bytes());
    b[49..49 + WIDTH].copy_from_slice(&payload);
    let hash = frame_hash(a.generation, &b[..FRAME - 32]);
    b[FRAME - 32..].copy_from_slice(&hash);
    Ok(b)
}
fn operation(b: &[u8; FRAME]) -> Result<Operation> {
    let slot = usize::try_from(num(&b[41..49]))?;
    require(slot < MAX_SLOTS, "operation slot limit")?;
    let raw: &[u8; WIDTH] = b[49..49 + WIDTH].try_into().unwrap();
    match b[40] {
        1 => Ok(Operation::Insert {
            slot,
            record: decode(raw),
        }),
        2 => Ok(Operation::Update {
            slot,
            record: decode(raw),
        }),
        3 => {
            require(raw.iter().all(|&v| v == 0), "noncanonical tombstone")?;
            Ok(Operation::Delete { slot })
        }
        _ => Err("operation kind".into()),
    }
}
pub fn replay<R: Read>(
    r: &mut R,
    len: u64,
    a: Anchor,
    mut table: Table,
    budget: u64,
) -> Result<Table> {
    Anchor::parse(&a.bytes(), None)?;
    require(table.sequence == a.base_sequence, "base revision")?;
    let prefix = WAL_HEAD as u64 + a.frames * FRAME as u64;
    require(
        len >= prefix && len <= WAL_HEAD as u64 + (MAX_FRAMES + 1) * FRAME as u64,
        "journal size",
    )?;
    let mut head = [0; WAL_HEAD];
    r.read_exact(&mut head)?;
    require(
        head == wal_header(a.generation, a.snapshot),
        "journal header",
    )?;
    let mut prev = digest(&head);
    for _ in 0..a.frames {
        let mut b = [0; FRAME];
        r.read_exact(&mut b)?;
        require(
            num(&b[..8]) == table.sequence.checked_add(1).ok_or("sequence overflow")?
                && b[8..40] == prev,
            "journal chain",
        )?;
        let pin = frame_hash(a.generation, &b[..FRAME - 32]);
        require(pin == b[FRAME - 32..], "frame hash")?;
        let op = operation(&b)?;
        if matches!(op, Operation::Insert { .. }) {
            require(
                (table.rows.len() as u64 + 1) * std::mem::size_of::<Option<Record>>() as u64
                    <= budget,
                "RAM budget",
            )?;
            table.rows.try_reserve_exact(1)?;
        }
        table.apply(op)?;
        prev = pin;
    }
    require(
        prev == a.tail && table.sequence == a.sequence,
        "committed tail",
    )?;
    Ok(table)
}
pub fn read_snapshot<R: Read>(r: &mut R, len: u64, a: Anchor, budget: u64) -> Result<Table> {
    Anchor::parse(&a.bytes(), None)?;
    let mut head = [0; 40];
    r.read_exact(&mut head)?;
    require(
        &head[..8] == SNAP_MAGIC
            && num(&head[8..16]) == a.generation
            && num(&head[16..24]) == a.base_sequence
            && num(&head[32..40]) == WIDTH as u64,
        "snapshot header",
    )?;
    let count = num(&head[24..32]);
    require(
        count <= MAX_SLOTS as u64 && len == count * (WIDTH as u64 + 1) + 72,
        "snapshot size",
    )?;
    require(
        count * std::mem::size_of::<Option<Record>>() as u64 <= budget,
        "RAM budget",
    )?;
    let mut rows = Vec::new();
    rows.try_reserve_exact(usize::try_from(count)?)?;
    let mut h = Sha256::new();
    h.update(head);
    for _ in 0..count {
        let mut b = [0; WIDTH + 1];
        r.read_exact(&mut b)?;
        h.update(b);
        require(b[0] <= 1, "slot flag")?;
        if b[0] == 0 {
            require(b[1..].iter().all(|&x| x == 0), "tombstone bytes")?;
            rows.push(None);
        } else {
            rows.push(Some(decode(b[1..].try_into().unwrap())));
        }
    }
    let mut pin = [0; 32];
    r.read_exact(&mut pin)?;
    require(
        pin == a.snapshot && pin == Pin::from(h.finalize()),
        "snapshot pin",
    )?;
    let mut extra = [0];
    require(r.read(&mut extra)? == 0, "trailing snapshot bytes")?;
    Ok(Table {
        rows,
        sequence: a.base_sequence,
    })
}
pub fn load(
    data: &Path,
    trust: &Path,
    expected: Option<Pin>,
    budget: u64,
) -> Result<(Anchor, Table)> {
    let a = trusted_anchor(trust, expected)?;
    let (s, w) = paths(data, a.generation);
    let f = regular(&s)?;
    let len = f.metadata()?.len();
    let table = read_snapshot(&mut BufReader::with_capacity(1 << 20, f), len, a, budget)?;
    let f = regular(&w)?;
    let len = f.metadata()?.len();
    let table = replay(&mut BufReader::new(f), len, a, table, budget)?;
    Ok((a, table))
}
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Stage {
    SnapshotHalf,
    SnapshotSynced,
    WalCreated,
    DataDirSynced,
    WalHalf,
    WalSynced,
    AnchorStaged,
    AnchorRenamed,
    AnchorDirSynced,
}
pub type Hook<'a> = dyn FnMut(Stage) -> Result<()> + 'a;
fn publish(trust: &Path, a: Anchor, hook: &mut Hook<'_>) -> Result<()> {
    let mut chosen = None;
    for i in 0..1000 {
        let p = trust.join(format!(".anchor-{}-{}-{i}", std::process::id(), a.sequence));
        match new_file(&p) {
            Ok(f) => {
                chosen = Some((p, f));
                break;
            }
            Err(e) => {
                if !p.exists() {
                    return Err(e);
                }
            }
        }
    }
    let (p, mut f) = chosen.ok_or("anchor staging collision")?;
    f.write_all(&a.bytes())?;
    f.sync_all()?;
    hook(Stage::AnchorStaged)?;
    fs::rename(&p, trust.join("CURRENT"))?;
    hook(Stage::AnchorRenamed)?;
    File::open(trust)?.sync_all()?;
    hook(Stage::AnchorDirSynced)?;
    Ok(())
}
fn snapshot(data: &Path, g: u64, table: &Table, hook: &mut Hook<'_>) -> Result<Anchor> {
    let (s, w) = paths(data, g);
    let mut out = BufWriter::with_capacity(1 << 20, new_file(&s)?);
    let mut head = [0; 40];
    head[..8].copy_from_slice(SNAP_MAGIC);
    head[8..16].copy_from_slice(&g.to_le_bytes());
    head[16..24].copy_from_slice(&table.sequence.to_le_bytes());
    head[24..32].copy_from_slice(&(table.rows.len() as u64).to_le_bytes());
    head[32..].copy_from_slice(&(WIDTH as u64).to_le_bytes());
    out.write_all(&head)?;
    let mut h = Sha256::new();
    h.update(head);
    for (i, row) in table.rows.iter().enumerate() {
        let mut b = [0; WIDTH + 1];
        if let Some(r) = row {
            b[0] = 1;
            b[1..].copy_from_slice(&encode(r));
        }
        h.update(b);
        out.write_all(&b)?;
        if i + 1 == (table.rows.len() + 1) / 2 {
            out.flush()?;
            hook(Stage::SnapshotHalf)?;
        }
    }
    let pin: Pin = h.finalize().into();
    out.write_all(&pin)?;
    out.flush()?;
    out.get_ref().sync_all()?;
    hook(Stage::SnapshotSynced)?;
    let header = wal_header(g, pin);
    let mut wal = new_file(&w)?;
    wal.write_all(&header)?;
    wal.sync_all()?;
    hook(Stage::WalCreated)?;
    File::open(data)?.sync_all()?;
    hook(Stage::DataDirSynced)?;
    Ok(Anchor {
        generation: g,
        sequence: table.sequence,
        base_sequence: table.sequence,
        snapshot: pin,
        tail: digest(&header),
        frames: 0,
    })
}
pub struct Writer {
    _lease: lease::Lease,
    _anchor_lease: lease::Lease,
    data: PathBuf,
    trust: PathBuf,
    anchor: Anchor,
    table: Table,
    poisoned: bool,
}
impl Writer {
    pub fn anchor(&self) -> Anchor {
        self.anchor
    }
    pub fn table(&self) -> &Table {
        &self.table
    }
    pub fn initialize(
        data: &Path,
        trust: &Path,
        table: Table,
        hook: &mut Hook<'_>,
    ) -> Result<Self> {
        let lease = lease::Lease::acquire(&data.join("WRITER.lock"))?;
        let anchor_lease = lease::Lease::acquire(&trust.join("ANCHOR.lock"))?;
        require(
            trust
                .join("CURRENT")
                .symlink_metadata()
                .is_err_and(|e| e.kind() == std::io::ErrorKind::NotFound),
            "anchor exists or inaccessible",
        )?;
        require(
            table.sequence == 0 && table.rows.len() <= MAX_SLOTS,
            "initial table",
        )?;
        let a = snapshot(data, 1, &table, hook)?;
        publish(trust, a, hook)?;
        Ok(Self {
            _lease: lease,
            _anchor_lease: anchor_lease,
            data: data.into(),
            trust: trust.into(),
            anchor: a,
            table,
            poisoned: false,
        })
    }
    pub fn open(data: &Path, trust: &Path, expected: Option<Pin>, budget: u64) -> Result<Self> {
        let lease = lease::Lease::acquire(&data.join("WRITER.lock"))?;
        let anchor_lease = lease::Lease::acquire(&trust.join("ANCHOR.lock"))?;
        let (a, t) = load(data, trust, expected, budget)?;
        Ok(Self {
            _lease: lease,
            _anchor_lease: anchor_lease,
            data: data.into(),
            trust: trust.into(),
            anchor: a,
            table: t,
            poisoned: false,
        })
    }
    pub fn commit(
        &mut self,
        expected_seq: u64,
        op: Operation,
        hook: &mut Hook<'_>,
    ) -> Result<Anchor> {
        require(!self.poisoned, "poisoned writer")?;
        require(
            trusted_anchor(&self.trust, None)? == self.anchor,
            "anchor changed outside writer",
        )?;
        require(
            expected_seq == self.anchor.sequence && self.table.sequence == expected_seq,
            "revision conflict",
        )?;
        require(self.anchor.frames < MAX_FRAMES, "checkpoint required")?;
        self.table.validate(&op)?;
        if matches!(op, Operation::Insert { .. }) {
            self.table.rows.try_reserve_exact(1)?;
        }
        let bytes = frame(self.anchor, &op)?;
        let mut next = self.anchor;
        next.sequence += 1;
        next.frames += 1;
        next.tail = bytes[FRAME - 32..].try_into().unwrap();
        self.poisoned = true;
        let path = paths(&self.data, self.anchor.generation).1;
        require(fs::symlink_metadata(&path)?.is_file(), "nonregular journal")?;
        let mut wal = OpenOptions::new().read(true).write(true).open(path)?;
        let prefix = WAL_HEAD as u64 + self.anchor.frames * FRAME as u64;
        require(wal.metadata()?.len() >= prefix, "short committed journal")?;
        wal.set_len(prefix)?;
        wal.sync_all()?;
        wal.seek(SeekFrom::Start(prefix))?;
        wal.write_all(&bytes[..FRAME / 2])?;
        hook(Stage::WalHalf)?;
        wal.write_all(&bytes[FRAME / 2..])?;
        wal.sync_all()?;
        hook(Stage::WalSynced)?;
        publish(&self.trust, next, hook)?;
        self.table.apply(op)?;
        self.anchor = next;
        self.poisoned = false;
        Ok(next)
    }
    pub fn checkpoint(&mut self, hook: &mut Hook<'_>) -> Result<Anchor> {
        require(!self.poisoned, "poisoned writer")?;
        require(
            trusted_anchor(&self.trust, None)? == self.anchor,
            "anchor changed outside writer",
        )?;
        let mut g = self
            .anchor
            .generation
            .checked_add(1)
            .ok_or("generation overflow")?;
        while {
            let (s, w) = paths(&self.data, g);
            s.try_exists()? || w.try_exists()?
        } {
            g = g.checked_add(1).ok_or("generation overflow")?;
        }
        self.poisoned = true;
        let next = snapshot(&self.data, g, &self.table, hook)?;
        publish(&self.trust, next, hook)?;
        self.anchor = next;
        self.poisoned = false;
        Ok(next)
    }
}
