use gel_p2_lab::*;
use o3::{Policy, PreparedBank, Reader, Record};
use std::{
    fs,
    io::Cursor,
    path::PathBuf,
    sync::atomic::{AtomicU64, Ordering},
};
struct Temp(PathBuf);
impl Temp {
    fn new() -> Self {
        static N: AtomicU64 = AtomicU64::new(0);
        for _ in 0..1000 {
            let p = std::env::temp_dir().join(format!(
                "gel-p2-{}-{}",
                std::process::id(),
                N.fetch_add(1, Ordering::Relaxed)
            ));
            if fs::create_dir(&p).is_ok() {
                fs::create_dir(p.join("data")).unwrap();
                fs::create_dir(p.join("trust")).unwrap();
                return Self(p);
            }
        }
        panic!("temp");
    }
    fn data(&self) -> PathBuf {
        self.0.join("data")
    }
    fn trust(&self) -> PathBuf {
        self.0.join("trust")
    }
}
impl Drop for Temp {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.0);
    }
}
fn rec(v: u8) -> Record {
    Record::new([v; 1024], &std::array::from_fn(|j| j % 5 != 0))
}
fn make(t: &Temp) -> Writer {
    Writer::initialize(
        &t.data(),
        &t.trust(),
        Table::new(vec![rec(1), rec(2), rec(3)]).unwrap(),
        &mut |_| Ok(()),
    )
    .unwrap()
}
fn state(t: &Table) -> Vec<Option<[u8; WIDTH]>> {
    t.rows.iter().map(|r| r.as_ref().map(encode)).collect()
}
fn rank(t: &Table) -> Vec<(usize, u64)> {
    let ids: Vec<_> = t
        .rows
        .iter()
        .enumerate()
        .filter_map(|(i, r)| r.as_ref().map(|_| i))
        .collect();
    let bank = PreparedBank::new(t.rows.iter().flatten().cloned().collect());
    let reader = Reader::new(51);
    let mut out = Vec::new();
    reader
        .scan_adaptive_into(
            &reader.prepare(rec(91)),
            &bank,
            Policy::BodyActivity,
            1,
            &mut out,
        )
        .unwrap();
    ids.into_iter()
        .zip(out.iter().map(|s| s.value().to_bits()))
        .collect()
}
#[test]
fn insert_update_delete_restart_checkpoint_and_rank() {
    let t = Temp::new();
    let mut w = make(&t);
    let old = w.anchor();
    w.commit(
        0,
        Operation::Update {
            slot: 0,
            record: rec(91),
        },
        &mut |_| Ok(()),
    )
    .unwrap();
    w.commit(1, Operation::Delete { slot: 1 }, &mut |_| Ok(()))
        .unwrap();
    w.commit(
        2,
        Operation::Insert {
            slot: 3,
            record: rec(12),
        },
        &mut |_| Ok(()),
    )
    .unwrap();
    let expected = state(w.table());
    let score = rank(w.table());
    let pin = w.anchor().pin();
    assert!(w
        .commit(0, Operation::Delete { slot: 0 }, &mut |_| Ok(()))
        .is_err());
    assert!(w
        .commit(
            3,
            Operation::Update {
                slot: 1,
                record: rec(4)
            },
            &mut |_| Ok(())
        )
        .is_err());
    assert!(w
        .commit(
            3,
            Operation::Insert {
                slot: 2,
                record: rec(4)
            },
            &mut |_| Ok(())
        )
        .is_err());
    drop(w);
    let (a, loaded) = load(&t.data(), &t.trust(), Some(pin), 100000).unwrap();
    assert_eq!(state(&loaded), expected);
    assert_eq!(rank(&loaded), score);
    assert_eq!(a.sequence, 3);
    assert!(load(&t.data(), &t.trust(), Some(old.pin()), 100000).is_err());
    let mut w = Writer::open(&t.data(), &t.trust(), Some(pin), 100000).unwrap();
    let a = w.checkpoint(&mut |_| Ok(())).unwrap();
    assert_eq!(a.generation, 2);
    assert_eq!(a.base_sequence, 3);
    assert_eq!(a.frames, 0);
    drop(w);
    let (_, loaded) = load(&t.data(), &t.trust(), Some(a.pin()), 100000).unwrap();
    assert_eq!(state(&loaded), expected);
    assert_eq!(rank(&loaded), score);
    assert!(t
        .data()
        .join("generation-00000000000000000001.snapshot")
        .exists());
}
#[test]
fn all_wal_prefixes_and_byte_corruption() {
    let t = Temp::new();
    let mut w = make(&t);
    let base = w.anchor();
    let initial = w.table().clone();
    w.commit(
        0,
        Operation::Update {
            slot: 0,
            record: rec(77),
        },
        &mut |_| Ok(()),
    )
    .unwrap();
    w.commit(1, Operation::Delete { slot: 1 }, &mut |_| Ok(()))
        .unwrap();
    w.commit(
        2,
        Operation::Insert {
            slot: 3,
            record: rec(44),
        },
        &mut |_| Ok(()),
    )
    .unwrap();
    let final_anchor = w.anchor();
    let expected = state(w.table());
    let bytes = fs::read(t.data().join("generation-00000000000000000001.wal")).unwrap();
    for cut in 0..bytes.len() {
        assert!(
            replay(
                &mut Cursor::new(&bytes[..cut]),
                cut as u64,
                final_anchor,
                initial.clone(),
                100000
            )
            .is_err(),
            "committed truncation {cut}"
        );
        if cut >= WAL_HEAD {
            assert_eq!(
                state(
                    &replay(
                        &mut Cursor::new(&bytes[..cut]),
                        cut as u64,
                        base,
                        initial.clone(),
                        100000
                    )
                    .unwrap()
                ),
                state(&initial)
            );
        }
    }
    for i in 0..bytes.len() {
        let mut bad = bytes.clone();
        bad[i] ^= 1;
        assert!(
            replay(
                &mut Cursor::new(&bad),
                bad.len() as u64,
                final_anchor,
                initial.clone(),
                100000
            )
            .is_err(),
            "corrupt byte {i}"
        );
    }
    assert_eq!(
        state(
            &replay(
                &mut Cursor::new(&bytes),
                bytes.len() as u64,
                final_anchor,
                initial.clone(),
                100000
            )
            .unwrap()
        ),
        expected
    );
    assert!(replay(
        &mut Cursor::new(&bytes),
        bytes.len() as u64,
        Anchor {
            frames: u64::MAX,
            ..final_anchor
        },
        initial,
        100000
    )
    .is_err());
}
#[test]
fn snapshot_truncation_corruption_anchor_and_budget() {
    let t = Temp::new();
    let w = make(&t);
    let a = w.anchor();
    let bytes = fs::read(t.data().join("generation-00000000000000000001.snapshot")).unwrap();
    for cut in 0..bytes.len() {
        assert!(read_snapshot(&mut Cursor::new(&bytes[..cut]), cut as u64, a, 100000).is_err());
    }
    for i in 0..bytes.len() {
        let mut bad = bytes.clone();
        bad[i] ^= 1;
        assert!(
            read_snapshot(&mut Cursor::new(&bad), bad.len() as u64, a, 100000).is_err(),
            "snapshot byte {i}"
        );
    }
    assert!(read_snapshot(&mut Cursor::new(&bytes), bytes.len() as u64, a, 1).is_err());
    for cut in 0..136 {
        assert!(Anchor::parse(&a.bytes()[..cut], None).is_err());
    }
    for i in 0..136 {
        let mut b = a.bytes();
        b[i] ^= 1;
        assert!(Anchor::parse(&b, None).is_err());
    }
    assert!(Anchor::parse(
        &Anchor {
            frames: 1,
            sequence: u64::MAX,
            base_sequence: u64::MAX,
            ..a
        }
        .bytes(),
        None
    )
    .is_err());
}
#[test]
fn writer_exclusion_poison_and_orphan_generation() {
    let t = Temp::new();
    let mut w = make(&t);
    assert!(Writer::open(&t.data(), &t.trust(), None, 100000).is_err());
    assert!(w
        .commit(
            0,
            Operation::Update {
                slot: 0,
                record: rec(9)
            },
            &mut |s| if s == Stage::WalHalf {
                Err("injected".into())
            } else {
                Ok(())
            }
        )
        .is_err());
    assert!(w
        .commit(0, Operation::Delete { slot: 0 }, &mut |_| Ok(()))
        .is_err());
    drop(w);
    let mut w = Writer::open(&t.data(), &t.trust(), None, 100000).unwrap();
    assert_eq!(w.anchor().sequence, 0);
    w.commit(0, Operation::Delete { slot: 0 }, &mut |_| Ok(()))
        .unwrap();
    assert!(w
        .checkpoint(&mut |s| if s == Stage::SnapshotHalf {
            Err("injected".into())
        } else {
            Ok(())
        })
        .is_err());
    drop(w);
    let mut w = Writer::open(&t.data(), &t.trust(), None, 100000).unwrap();
    assert_eq!(w.anchor().generation, 1);
    assert!(w.table().rows[0].is_none());
    assert_eq!(w.checkpoint(&mut |_| Ok(())).unwrap().generation, 3);
}
#[test]
fn empty_table_and_nonregular_files_are_handled() {
    let t = Temp::new();
    let mut w = Writer::initialize(
        &t.data(),
        &t.trust(),
        Table::new(vec![]).unwrap(),
        &mut |_| Ok(()),
    )
    .unwrap();
    w.commit(
        0,
        Operation::Insert {
            slot: 0,
            record: rec(9),
        },
        &mut |_| Ok(()),
    )
    .unwrap();
    w.commit(1, Operation::Delete { slot: 0 }, &mut |_| Ok(()))
        .unwrap();
    let a = w.checkpoint(&mut |_| Ok(())).unwrap();
    drop(w);
    let (_, table) = load(&t.data(), &t.trust(), Some(a.pin()), 100000).unwrap();
    assert!(table.rows[0].is_none());
    let anchor = t.trust().join("CURRENT");
    fs::rename(&anchor, t.trust().join("saved")).unwrap();
    std::os::unix::fs::symlink(t.trust().join("saved"), &anchor).unwrap();
    assert!(load(&t.data(), &t.trust(), None, 100000).is_err());
}
