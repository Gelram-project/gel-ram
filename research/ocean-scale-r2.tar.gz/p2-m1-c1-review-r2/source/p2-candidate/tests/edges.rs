//! Supplementary audit after the frozen large P2 run; production code unchanged.
use gel_p2_lab::*;
use o3::Record;
use sha2::{Digest,Sha256};
use std::{fs, path::PathBuf, sync::atomic::{AtomicU64,Ordering}};
struct Temp(PathBuf);
impl Temp {
    fn new()->Self {static N:AtomicU64=AtomicU64::new(0);for _ in 0..1000 {
        let p=std::env::temp_dir().join(format!("gel-p2-edges-{}-{}",std::process::id(),N.fetch_add(1,Ordering::Relaxed)));
        if fs::create_dir(&p).is_ok(){fs::create_dir(p.join("data")).unwrap();fs::create_dir(p.join("trust")).unwrap();return Self(p);}
    }panic!("temp");}
    fn data(&self)->PathBuf{self.0.join("data")}
    fn trust(&self)->PathBuf{self.0.join("trust")}
    fn make(&self)->Writer{Writer::initialize(&self.data(),&self.trust(),Table::new(vec![rec()]).unwrap(),&mut |_|Ok(())).unwrap()}
}
impl Drop for Temp{fn drop(&mut self){let _=fs::remove_dir_all(&self.0);}}
fn rec()->Record{Record::new([10;1024],&[true;1024])}
#[test]
fn full_journal_requires_checkpoint_then_resumes_monotonic_sequence(){
    let t=Temp::new();let w=t.make();let mut a=w.anchor();drop(w);
    let path=t.data().join("generation-00000000000000000001.wal");
    let mut wal=fs::read(&path).unwrap();
    for seq in 1..=MAX_FRAMES {
        let mut frame=Vec::new();frame.extend(seq.to_le_bytes());frame.extend(a.tail);
        frame.push(2);frame.extend(0u64.to_le_bytes());frame.extend(encode(&rec()));
        let mut h=Sha256::new();h.update(b"GEL-P2-FRAME");h.update(a.generation.to_le_bytes());h.update(&frame);
        a.tail=h.finalize().into();frame.extend(a.tail);wal.extend(frame);a.sequence=seq;a.frames=seq;
    }
    fs::write(&path,&wal).unwrap();fs::write(t.trust().join("CURRENT"),a.bytes()).unwrap();
    let mut w=Writer::open(&t.data(),&t.trust(),Some(a.pin()),100000).unwrap();
    let error=w.commit(MAX_FRAMES,Operation::Delete{slot:0},&mut |_|Ok(())).err().unwrap();
    assert_eq!(error.to_string(),"checkpoint required");assert_eq!(fs::read(&path).unwrap(),wal);
    let checkpoint=w.checkpoint(&mut |_|Ok(())).unwrap();
    assert_eq!(checkpoint.base_sequence,MAX_FRAMES);assert_eq!(checkpoint.frames,0);
    let final_anchor=w.commit(MAX_FRAMES,Operation::Delete{slot:0},&mut |_|Ok(())).unwrap();drop(w);
    let (_,table)=load(&t.data(),&t.trust(),Some(final_anchor.pin()),100000).unwrap();
    assert_eq!(table.sequence,MAX_FRAMES+1);assert!(table.rows[0].is_none());
}
#[test]
fn shared_anchor_lock_excludes_second_data_directory(){
    let a=Temp::new();let b=Temp::new();let w=a.make();
    let before=fs::read(a.trust().join("CURRENT")).unwrap();
    let err=Writer::open(&b.data(),&a.trust(),None,100000).err().unwrap();
    assert!(err.to_string().contains("os error 11"));
    assert_eq!(fs::read(a.trust().join("CURRENT")).unwrap(),before);drop(w);
}
#[test]
fn external_anchor_change_is_not_overwritten_by_active_writer(){
    let t=Temp::new();let mut w=t.make();
    let changed=Anchor{generation:99,..w.anchor()};
    fs::write(t.trust().join("CURRENT"),changed.bytes()).unwrap();
    assert!(w.commit(0,Operation::Delete{slot:0},&mut |_|Ok(())).is_err());
    assert!(w.checkpoint(&mut |_|Ok(())).is_err());
    assert_eq!(trusted_anchor(&t.trust(),None).unwrap(),changed);
}
