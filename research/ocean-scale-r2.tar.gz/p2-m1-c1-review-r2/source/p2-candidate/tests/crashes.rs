use std::{
    fs,
    io::Write,
    path::{Path, PathBuf},
    process::{Child, Command, Stdio},
    time::{Duration, Instant},
};
struct ChildGuard(Child);
impl Drop for ChildGuard {
    fn drop(&mut self) {
        let _ = self.0.kill();
        let _ = self.0.wait();
    }
}
struct Temp(PathBuf);
impl Drop for Temp {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.0);
    }
}
fn run(action: &str, root: &Path, args: &[&str]) -> String {
    let out = Command::new(env!("CARGO_BIN_EXE_p2_probe"))
        .arg(action)
        .arg(root)
        .arg("128")
        .args(args)
        .output()
        .unwrap();
    assert!(
        out.status.success(),
        "{action}: {}",
        String::from_utf8_lossy(&out.stderr)
    );
    String::from_utf8(out.stdout).unwrap()
}
#[test]
fn every_commit_and_checkpoint_hook_survives_sigkill() {
    let base = std::env::temp_dir().join(format!("gel-p2-crashes-{}", std::process::id()));
    fs::create_dir(&base).unwrap();
    let _temp = Temp(base.clone());
    let mut log = String::new();
    for (kind, stages) in [
        (
            "commit",
            vec![
                "WalHalf",
                "WalSynced",
                "AnchorStaged",
                "AnchorRenamed",
                "AnchorDirSynced",
            ],
        ),
        (
            "checkpoint",
            vec![
                "SnapshotHalf",
                "SnapshotSynced",
                "WalCreated",
                "DataDirSynced",
                "AnchorStaged",
                "AnchorRenamed",
                "AnchorDirSynced",
            ],
        ),
    ] {
        for stage in stages {
            let root = base.join(format!("{kind}-{stage}"));
            run("seed", &root, &[]);
            let before = if kind == "checkpoint" {
                run("mutate", &root, &[]);
                4
            } else {
                0
            };
            let marker = base.join(format!("{kind}-{stage}.marker"));
            let mut child = ChildGuard(
                Command::new(env!("CARGO_BIN_EXE_p2_probe"))
                    .arg("crash")
                    .arg(&root)
                    .args(["128", kind, stage])
                    .arg(&marker)
                    .stdout(Stdio::null())
                    .stderr(Stdio::inherit())
                    .spawn()
                    .unwrap(),
            );
            let started = Instant::now();
            while !marker.exists() {
                assert!(
                    started.elapsed() < Duration::from_secs(15),
                    "marker timeout"
                );
                assert!(
                    child.0.try_wait().unwrap().is_none(),
                    "premature child exit"
                );
                std::thread::sleep(Duration::from_millis(5));
            }
            assert_eq!(fs::read_to_string(&marker).unwrap().trim(), stage);
            let competing = Command::new(env!("CARGO_BIN_EXE_p2_probe"))
                .arg("retry")
                .arg(&root)
                .arg("128")
                .output()
                .unwrap();
            assert!(!competing.status.success());
            assert!(
                String::from_utf8_lossy(&competing.stderr).contains("os error 11"),
                "writer exclusion"
            );
            child.0.kill().unwrap();
            let status = child.0.wait().unwrap();
            assert!(!status.success());
            let after = if kind == "commit" && ["AnchorRenamed", "AnchorDirSynced"].contains(&stage)
            {
                1
            } else {
                before
            };
            let result = run("verify", &root, &[&after.to_string()]);
            assert!(result.contains("RECONSTRUCTION=BIT_EQUAL"));
            let generation =
                if kind == "checkpoint" && ["AnchorRenamed", "AnchorDirSynced"].contains(&stage) {
                    2
                } else {
                    1
                };
            assert!(result
                .lines()
                .any(|l| l == format!("GENERATION={generation}")));
            if kind == "commit" {
                run("retry", &root, &[]);
                run("verify", &root, &["1"]);
            } else {
                run("checkpoint", &root, &[]);
                let again = run("verify", &root, &["4"]);
                assert!(again.lines().any(|l| l == "GENERATION=3"));
                for field in ["RANK_updated=", "RANK_deleted=", "RANK_inserted="] {
                    assert_eq!(
                        result.lines().find(|l| l.starts_with(field)),
                        again.lines().find(|l| l.starts_with(field))
                    );
                }
            }
            log.push_str(&format!(
                "{kind} {stage}: old_or_new={after}, restart+ranking+retry PASS\n"
            ));
        }
    }
    if let Some(p) = std::env::var_os("P2_CRASH_EVIDENCE") {
        let mut f = fs::OpenOptions::new()
            .create_new(true)
            .write(true)
            .open(p)
            .unwrap();
        f.write_all(log.as_bytes()).unwrap();
        f.sync_all().unwrap();
    }
    print!("{log}");
}
