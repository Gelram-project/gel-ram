use gel_p2_lab::*;
use o3::Record;
use sha2::{Digest, Sha256};
use std::io::Cursor;
fn fixture(kind: u8, id: u64, seq: u64, payload: [u8; WIDTH]) -> (Anchor, Vec<u8>, Table) {
    let record = Record::new([21; 1024], &[true; 1024]);
    let table = Table::new(vec![record]).unwrap();
    let snapshot = [7; 32];
    let mut header = Vec::from(*b"GELP2W01");
    header.extend(1u64.to_le_bytes());
    header.extend(snapshot);
    let mut frame = Vec::new();
    frame.extend(seq.to_le_bytes());
    frame.extend(digest(&header));
    frame.push(kind);
    frame.extend(id.to_le_bytes());
    frame.extend(payload);
    let mut h = Sha256::new();
    h.update(b"GEL-P2-FRAME");
    h.update(1u64.to_le_bytes());
    h.update(&frame);
    let pin: Pin = h.finalize().into();
    frame.extend(pin);
    header.extend(frame);
    (
        Anchor {
            generation: 1,
            sequence: 1,
            base_sequence: 0,
            snapshot,
            tail: pin,
            frames: 1,
        },
        header,
        table,
    )
}
#[test]
fn a_valid_hash_does_not_authorize_invalid_operations() {
    for (kind, id, seq, payload) in [
        (1, 0, 1, [0; WIDTH]),
        (1, 2, 1, [0; WIDTH]),
        (2, MAX_SLOTS as u64, 1, [0; WIDTH]),
        (3, 0, 1, [1; WIDTH]),
        (4, 0, 1, [0; WIDTH]),
        (2, 0, 2, [0; WIDTH]),
    ] {
        let (a, b, t) = fixture(kind, id, seq, payload);
        assert!(replay(&mut Cursor::new(&b), b.len() as u64, a, t, 100000).is_err());
    }
}
#[test]
fn rehashing_data_without_changing_trusted_tail_fails() {
    let (a, mut b, t) = fixture(2, 0, 1, [0; WIDTH]);
    b[WAL_HEAD + 49] ^= 1;
    let mut h = Sha256::new();
    h.update(b"GEL-P2-FRAME");
    h.update(1u64.to_le_bytes());
    h.update(&b[WAL_HEAD..WAL_HEAD + FRAME - 32]);
    let pin: Pin = h.finalize().into();
    b[WAL_HEAD + FRAME - 32..].copy_from_slice(&pin);
    assert!(replay(&mut Cursor::new(&b), b.len() as u64, a, t, 100000).is_err());
}
