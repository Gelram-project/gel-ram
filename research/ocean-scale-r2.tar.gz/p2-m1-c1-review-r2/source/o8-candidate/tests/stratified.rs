//! Additional export gate; no effect on the frozen benchmark binaries.
use gel_phase_quad as reference;
use o3::{Policy, PreparedBank, Reader, Record};
fn next(s: &mut u64) -> u64 {
    *s = s.wrapping_add(0x9e3779b97f4a7c15);
    let mut x = *s;
    x = (x ^ (x >> 30)).wrapping_mul(0xbf58476d1ce4e5b9);
    x = (x ^ (x >> 27)).wrapping_mul(0x94d049bb133111eb);
    x ^ (x >> 31)
}
#[test]
fn independent_public_reader_matches_4096_stratified_cases() {
    let mut checked = 0;
    for bank_id in 0..32u64 {
        let mut rng = bank_id ^ 0x72616d67656c2026;
        let mut refs = Vec::new();
        let mut records = Vec::new();
        for id in 0..97 {
            let phase = std::array::from_fn(|_| next(&mut rng) as u8);
            let mask = std::array::from_fn(|_| match (bank_id + id) % 4 {
                0 => true,
                1 => false,
                2 => next(&mut rng) % 2 == 0,
                _ => next(&mut rng) % 17 == 0,
            });
            refs.push(reference::Record::new(phase, &mask));
            records.push(Record::new(phase, &mask));
        }
        let mut bank = PreparedBank::new(records);
        let fast = Reader::new(bank_id);
        let slow = reference::Reader::new(bank_id);
        for qi in 0..32 {
            let phase = std::array::from_fn(|_| next(&mut rng) as u8);
            let mask = std::array::from_fn(|j| match qi % 8 {
                0 => false,
                1 => true,
                2 => j == 1023,
                3 => j < 64,
                4 => j < 511,
                5 => j != 0,
                _ => next(&mut rng) % 3 == 0,
            });
            // Replace before querying: invalidation and the route must stay coherent.
            let id = qi * 3 % 97;
            bank.replace(id, Record::new(phase, &mask)).unwrap();
            refs[id] = reference::Record::new(phase, &mask);
            assert_eq!(
                bank.empty_count(),
                refs.iter()
                    .filter(|r| (0..1024).all(|j| !r.active(j).unwrap()))
                    .count()
            );
            let fq = fast.prepare(Record::new(phase, &mask));
            let sq = slow.prepare(reference::Record::new(phase, &mask));
            for (fp, sp) in [
                (Policy::BodyActivity, reference::Policy::BodyActivity),
                (Policy::Archive, reference::Policy::Archive),
            ] {
                for w in [1, 7] {
                    let mut expected = Vec::new();
                    let mut actual = Vec::new();
                    assert_eq!(
                        slow.scan_into(&sq, &refs, sp, 1, &mut expected),
                        fast.scan_adaptive_into(&fq, &bank, fp, w, &mut actual)
                    );
                    assert_eq!(expected.len(), actual.len());
                    for (a, b) in expected.iter().zip(&actual) {
                        assert_eq!(a.value().to_bits(), b.value().to_bits());
                    }
                    checked += 1;
                }
            }
        }
    }
    assert_eq!(checked, 4096);
}
