use gel_phase_quad as public;
use o3 as candidate;
#[test]
fn matches_unmodified_public_reader_for_deterministic_varied_data() {
    const D: usize = 1024;
    let mut rng = 0x876541ab_u64;
    let mut next = || {
        rng ^= rng << 13;
        rng ^= rng >> 7;
        rng ^= rng << 17;
        rng
    };
    let mut public_bank = Vec::new();
    let mut candidate_records = Vec::new();
    for id in 0..137 {
        let phase = std::array::from_fn(|_| next() as u8);
        let mask = std::array::from_fn(|_| match id % 4 {
            0 => false,
            1 => true,
            _ => next() % 5 == 0,
        });
        public_bank.push(public::Record::new(phase, &mask));
        candidate_records.push(candidate::Record::new(phase, &mask));
    }
    let bank = candidate::PreparedBank::new(candidate_records);
    let a = public::Reader::new(773);
    let b = candidate::Reader::new(773);
    for support in [0, 1, 2, 63, 64, 65, 511, 512, 1023, D] {
        let phase = std::array::from_fn(|_| next() as u8);
        let mask = std::array::from_fn(|j| j < support);
        let aq = a.prepare(public::Record::new(phase, &mask));
        let bq = b.prepare(candidate::Record::new(phase, &mask));
        for (ap, bp) in [
            (public::Policy::Archive, candidate::Policy::Archive),
            (
                public::Policy::BodyActivity,
                candidate::Policy::BodyActivity,
            ),
        ] {
            let mut expected = Vec::new();
            let mut actual = Vec::new();
            assert_eq!(
                a.scan_into(&aq, &public_bank, ap, 1, &mut expected),
                b.scan_adaptive_into(&bq, &bank, bp, 7, &mut actual)
            );
            assert_eq!(
                expected
                    .iter()
                    .map(|s| s.value().to_bits())
                    .collect::<Vec<_>>(),
                actual
                    .iter()
                    .map(|s| s.value().to_bits())
                    .collect::<Vec<_>>()
            );
        }
    }
}
