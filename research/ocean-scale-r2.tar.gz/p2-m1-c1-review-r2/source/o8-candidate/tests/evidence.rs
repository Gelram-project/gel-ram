use std::{
    fs,
    path::PathBuf,
    process::Command,
    sync::atomic::{AtomicU64, Ordering},
};
struct Temp(PathBuf);
impl Temp {
    fn new() -> Self {
        static ID: AtomicU64 = AtomicU64::new(0);
        let base = std::env::temp_dir();
        for _ in 0..1000 {
            let p = base.join(format!(
                "gel-o8-evidence-{}-{}",
                std::process::id(),
                ID.fetch_add(1, Ordering::Relaxed)
            ));
            if fs::create_dir(&p).is_ok() {
                return Self(p);
            }
        }
        panic!("temporary test directory unavailable");
    }
}
impl Drop for Temp {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.0);
    }
}
#[test]
fn reports_are_recomputed_and_corruption_rejected() {
    let t = Temp::new();
    let p = t.0.join("run");
    let result = Command::new(env!("CARGO_BIN_EXE_adaptive_o8"))
        .args(["257", "7", "2027", "sparse"])
        .arg(&p)
        .output()
        .unwrap();
    assert!(
        result.status.success(),
        "{}",
        String::from_utf8_lossy(&result.stderr)
    );
    let audit = || gel_o8_lab::audit::run(&p, 257, 7, 2027, "sparse");
    assert_eq!(audit().unwrap().rows.len(), 7);
    assert!(gel_o8_lab::audit::run(&p, 257, 7, 2027, "full").is_err());
    assert!(gel_o8_lab::audit::run(&p, 258, 7, 2027, "sparse").is_err());
    assert!(gel_o8_lab::audit::run(&p, 257, 1, 2027, "sparse").is_err());
    for (file, from, to) in [
        ("manifest.txt", "SEED=2027", "SEED=193"),
        ("manifest.txt", "THRESHOLD=0.99", "THRESHOLD=0.90"),
        ("summary.txt", "TRIPLES=42", "TRIPLES=43"),
        ("summary.txt", "BIT_EQUAL=PASS", "BIT_EQUAL=FAIL"),
        (
            "summary.txt",
            "STEADY_REALLOCATIONS=0",
            "STEADY_REALLOCATIONS=1",
        ),
        ("timings.csv", ",012,", ",021,"),
        ("timings.csv", ",HIT,0,", ",HIT,1,"),
        ("COMPLETE", "O8_THREE_PATH_PASS", "OTHER_PASS"),
    ] {
        let path = p.join(file);
        let original = fs::read_to_string(&path).unwrap();
        assert!(original.contains(from));
        fs::write(&path, original.replacen(from, to, 1)).unwrap();
        assert!(audit().is_err(), "accepted {file}: {from}");
        fs::write(&path, original).unwrap();
    }
    for file in ["manifest.txt", "summary.txt", "timings.csv", "top10.csv"] {
        let path = p.join(file);
        let original = fs::read_to_string(&path).unwrap();
        let duplicate = format!("{original}{}\n", original.lines().nth(1).unwrap());
        fs::write(&path, duplicate).unwrap();
        assert!(audit().is_err(), "duplicate {file}");
        fs::write(&path, &original).unwrap();
    }
    let path = p.join("top10.csv");
    let original = fs::read_to_string(&path).unwrap();
    let mut lines: Vec<_> = original.lines().map(str::to_string).collect();
    let mut f: Vec<_> = lines[1].split(',').map(str::to_string).collect();
    f[4] = "0.123".into();
    f[5] = "0.123".into();
    lines[1] = f.join(",");
    fs::write(&path, lines.join("\n")).unwrap();
    assert!(audit().is_err(), "matching fake score and oracle");
    fs::write(&path, &original).unwrap();
    let path = p.join("timings.csv");
    let original = fs::read_to_string(&path).unwrap();
    let mut lines: Vec<_> = original.lines().map(str::to_string).collect();
    let mut f: Vec<_> = lines[1].split(',').map(str::to_string).collect();
    f[6] = "1".into();
    lines[1] = f.join(",");
    fs::write(&path, lines.join("\n")).unwrap();
    assert!(audit().is_err(), "invalid nested time");
    fs::write(&path, &original).unwrap();
    assert!(audit().is_ok());
}
