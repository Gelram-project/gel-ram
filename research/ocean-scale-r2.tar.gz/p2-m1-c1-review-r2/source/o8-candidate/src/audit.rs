//! Evidence checks are independent of printed speedup/summary claims.
use crate::fixture::{body, cases, hash_record, kind, oracle};
use sha2::{Digest, Sha256};
use std::{
    collections::{BTreeMap, BTreeSet},
    fs,
    path::Path,
};
type Result<T> = std::result::Result<T, Box<dyn std::error::Error>>;
pub const HEADER:&str="cycle,class,order,base_prepare_ns,base_scan_ns,base_rank_ns,base_total_ns,o6_prepare_ns,o6_scan_ns,o6_rank_ns,o6_total_ns,adaptive_prepare_ns,adaptive_scan_ns,adaptive_rank_ns,adaptive_total_ns,reason,hit_id,score_sha256,reallocations";
pub struct Audit {
    pub rows: Vec<String>,
    pub corpus: String,
    pub scores: BTreeMap<String, String>,
}
fn check(b: bool) -> Result<()> {
    if b {
        Ok(())
    } else {
        Err("invalid O8 evidence".into())
    }
}
fn val<'a>(s: &'a str, k: &str) -> Result<&'a str> {
    let p = format!("{k}=");
    let v: Vec<_> = s.lines().filter_map(|l| l.strip_prefix(&p)).collect();
    check(v.len() == 1)?;
    Ok(v[0])
}
fn field(s: &str, k: &str, v: &str) -> Result<()> {
    check(val(s, k)? == v)
}
fn hex(s: &str) -> bool {
    s.len() == 64
        && s.bytes()
            .all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b))
}
fn median(v: &mut [f64]) -> f64 {
    v.sort_by(f64::total_cmp);
    v[(v.len() - 1) / 2]
}
pub fn run(dir: &Path, n: usize, w: usize, seed: u64, profile: &str) -> Result<Audit> {
    check(
        (32..=10_000_000).contains(&n)
            && (1..=64).contains(&w)
            && ["full", "balanced", "sparse"].contains(&profile),
    )?;
    check(
        fs::read_to_string(dir.join("COMPLETE"))?.trim() == "O8_THREE_PATH_PASS_NOT_PUBLIC_RELEASE",
    )?;
    let meta = fs::read_to_string(dir.join("manifest.txt"))?;
    for (k, v) in [
        ("FORMAT", "O8_THREE_PATH"),
        ("CYCLES", "6"),
        ("CLASSES", "7"),
        ("THRESHOLD", "0.99"),
        ("MARGIN", "0.000001"),
        ("MIN_SUPPORT", "32"),
        ("POLICY", "BodyActivity"),
        ("PROFILE", profile),
    ] {
        field(&meta, k, v)?;
    }
    for (k, v) in [
        ("ORB_COUNT", n),
        ("WORKERS", w),
        ("WORKERS_EFFECTIVE", o3::effective_workers(w, n)?),
    ] {
        field(&meta, k, &v.to_string())?;
    }
    field(&meta, "SEED", &seed.to_string())?;
    let inputs = cases(seed);
    let mut qh = Sha256::new();
    for c in &inputs {
        qh.update((c.name.len() as u64).to_le_bytes());
        qh.update(c.name.as_bytes());
        hash_record(&mut qh, &c.q);
    }
    let raw = fs::read_to_string(dir.join("timings.csv"))?;
    let mut lines = raw.lines();
    check(lines.next() == Some(HEADER))?;
    let mut seen = BTreeSet::new();
    let mut pins = BTreeMap::new();
    let mut groups: BTreeMap<usize, Vec<[u64; 12]>> = BTreeMap::new();
    const ORDER: [&str; 6] = ["012", "120", "201", "021", "210", "102"];
    for line in lines {
        let f: Vec<_> = line.split(',').collect();
        check(f.len() == 19)?;
        let cycle: usize = f[0].parse()?;
        let ci = inputs.iter().position(|c| c.name == f[1]).ok_or("class")?;
        check(
            cycle < 6
                && seen.insert((cycle, ci))
                && f[2] == ORDER[(cycle + ci) % 6]
                && f[18] == "0",
        )?;
        let mut t = [0u64; 12];
        for (i, x) in t.iter_mut().enumerate() {
            *x = f[3 + i].parse()?;
        }
        for c in t.chunks(4) {
            let sum = c[0]
                .checked_add(c[1])
                .and_then(|s| s.checked_add(c[2]))
                .ok_or("overflow")?;
            check(c[3] > 0 && c[3] >= sum)?;
        }
        check(
            f[15] == inputs[ci].reason
                && f[16] == inputs[ci].hit.map_or("NA".into(), |i| i.to_string())
                && hex(f[17]),
        )?;
        if ci == 6 {
            check(f[17] == format!("{:x}", Sha256::digest([])))?;
        }
        if let Some(old) = pins.insert(inputs[ci].name.to_string(), f[17].to_string()) {
            check(old == f[17])?;
        }
        groups.entry(ci).or_default().push(t);
    }
    check(seen.len() == 42 && groups.len() == 7)?;
    let raw = fs::read_to_string(dir.join("top10.csv"))?;
    let mut lines = raw.lines();
    check(lines.next() == Some("cycle,class,rank,id,score,oracle_score"))?;
    let mut tops: BTreeMap<(usize, usize), Vec<(usize, f64)>> = BTreeMap::new();
    for line in lines {
        let f: Vec<_> = line.split(',').collect();
        check(f.len() == 6)?;
        let cycle: usize = f[0].parse()?;
        let ci = inputs.iter().position(|c| c.name == f[1]).ok_or("class")?;
        check(seen.contains(&(cycle, ci)) && ci != 6)?;
        let rank: usize = f[2].parse()?;
        let id: usize = f[3].parse()?;
        let score: f64 = f[4].parse()?;
        let printed: f64 = f[5].parse()?;
        check(id < n && score.is_finite() && printed.is_finite() && score.abs() <= 1. + 1e-12)?;
        let truth = oracle(&inputs[ci].q, &body(id, seed, profile)).ok_or("oracle")?;
        check((score - truth).abs() <= 1e-12 && (printed - truth).abs() <= 1e-12)?;
        let rows = tops.entry((cycle, ci)).or_default();
        check(rank == rows.len() + 1 && rank <= 10 && !rows.iter().any(|r| r.0 == id))?;
        if let Some(&(old, s)) = rows.last() {
            check(score < s || (score == s && id > old))?;
        }
        rows.push((id, score));
    }
    check(tops.len() == 36 && tops.values().all(|v| v.len() == 10))?;
    let mut top_pins = BTreeMap::new();
    for ((_, ci), top) in tops {
        let c = &inputs[ci];
        let support = c.q.active_mask().iter().filter(|&&v| v).count();
        check(crate::fixture::decision(&top, support) == (c.reason, c.hit))?;
        let bits: Vec<_> = top.iter().map(|(i, s)| (*i, s.to_bits())).collect();
        if let Some(old) = top_pins.insert(ci, bits.clone()) {
            check(old == bits)?;
        }
    }
    let s = fs::read_to_string(dir.join("summary.txt"))?;
    for (k, v) in [
        ("TRIPLES", "42"),
        ("TOP_ORACLE_CHECKS", "360"),
        ("BIT_EQUAL", "PASS"),
        ("RANK_AND_DECISION_EQUAL", "PASS"),
        ("STEADY_REALLOCATIONS", "0"),
    ] {
        field(&s, k, v)?;
    }
    // Count in O(N) cheap integer operations, without materializing the bank.
    let mut counts = [0usize; 4];
    for id in 0..n {
        counts[kind(id, profile)] += 1;
    }
    for (k, v) in [
        ("SCORE_COMPARISONS", 72 * n),
        ("BANK_BYTES", 1152 * n),
        ("FLAGS_BYTES", n),
        ("BANK_HEADER_BYTES", std::mem::size_of::<o3::PreparedBank>()),
        ("EMPTY_COUNT", counts[3]),
        ("RESULT_BUFFERS_BYTES", 24 * n),
        ("FULL", counts[0]),
        ("HALF", counts[1]),
        ("SPARSE64", counts[2]),
        ("EMPTY", counts[3]),
    ] {
        field(&s, k, &v.to_string())?;
    }
    field(&s, "QUERY_SHA256", &format!("{:x}", qh.finalize()))?;
    let corpus = val(&s, "CORPUS_SHA256")?.to_string();
    check(hex(&corpus))?;
    check(val(&s, "FLAGS_PREPARE_NS")?.parse::<u64>()? > 0)?;
    let mut result = Vec::new();
    for (ci, rows) in groups {
        check(rows.len() == 6)?;
        let mut cols: [Vec<f64>; 12] =
            std::array::from_fn(|i| rows.iter().map(|r| r[i] as f64 / 1e6).collect());
        let med: Vec<_> = cols.iter_mut().map(|c| median(c)).collect();
        let mut ba: Vec<_> = rows.iter().map(|r| r[3] as f64 / r[11] as f64).collect();
        let mut oa: Vec<_> = rows.iter().map(|r| r[7] as f64 / r[11] as f64).collect();
        result.push(format!(
            "{n},{w},{seed},{profile},{},6,{:.6},{:.6},{:.6},{:.6},{:.6},{},{},{:.6},{:.6},{:.6}",
            inputs[ci].name,
            med[3],
            med[7],
            med[11],
            median(&mut ba),
            median(&mut oa),
            rows.iter().filter(|r| r[11] < r[3]).count(),
            rows.iter().filter(|r| r[11] < r[7]).count(),
            med[1],
            med[5],
            med[9]
        ));
    }
    Ok(Audit {
        rows: result,
        corpus,
        scores: pins,
    })
}
