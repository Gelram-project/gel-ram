#![forbid(unsafe_code)]
use o3::{grid::DIM, Record, SharedScore};
use sha2::{Digest, Sha256};
type Result<T> = std::result::Result<T, Box<dyn std::error::Error>>;
fn mix(mut v: u64) -> u64 {
    v = (v ^ (v >> 30)).wrapping_mul(0xbf58476d1ce4e5b9);
    v = (v ^ (v >> 27)).wrapping_mul(0x94d049bb133111eb);
    v ^ (v >> 31)
}
fn phase(id: u64, seed: u64) -> [u8; DIM] {
    let mut s = mix(seed ^ id);
    let mut p = [0; DIM];
    for chunk in p.chunks_mut(8) {
        s = s.wrapping_add(0x9e3779b97f4a7c15);
        chunk.copy_from_slice(&mix(s).to_le_bytes());
    }
    p
}
pub fn kind(id: usize, profile: &str) -> usize {
    if id < 5 || profile == "full" {
        0
    } else if profile == "balanced" {
        id % 4
    } else {
        match id % 10 {
            0 => 0,
            1..=3 => 1,
            4..=6 => 2,
            _ => 3,
        }
    }
}
pub fn body(id: usize, seed: u64, profile: &str) -> Record {
    let mask = std::array::from_fn(|j| match kind(id, profile) {
        0 => true,
        1 => (j + id) % 2 == 0,
        2 => (j + id) % 16 == 0,
        _ => false,
    });
    Record::new(phase(if id == 3 { 2 } else { id as u64 }, seed), &mask)
}
pub struct Case {
    pub name: &'static str,
    pub q: Record,
    pub reason: &'static str,
    pub hit: Option<usize>,
}
pub fn cases(seed: u64) -> Vec<Case> {
    let mut near = phase(4, seed);
    for x in &mut near[..64] {
        *x = x.wrapping_add(1);
    }
    vec![
        Case {
            name: "FULL_HIT",
            q: Record::new(phase(0, seed), &[true; DIM]),
            reason: "HIT",
            hit: Some(0),
        },
        Case {
            name: "PARTIAL_HIT",
            q: Record::new(phase(1, seed), &std::array::from_fn(|j| j < 64)),
            reason: "HIT",
            hit: Some(1),
        },
        Case {
            name: "NEAR_HIT",
            q: Record::new(near, &[true; DIM]),
            reason: "HIT",
            hit: Some(4),
        },
        Case {
            name: "MISS_RANDOM",
            q: Record::new(phase(u64::MAX, seed), &[true; DIM]),
            reason: "BELOW_THRESHOLD",
            hit: None,
        },
        Case {
            name: "DUPLICATE_TIE",
            q: Record::new(phase(2, seed), &[true; DIM]),
            reason: "AMBIGUOUS",
            hit: None,
        },
        Case {
            name: "WEAK_SUPPORT",
            q: Record::new(phase(0, seed), &std::array::from_fn(|j| j == 0)),
            reason: "WEAK_SUPPORT",
            hit: None,
        },
        Case {
            name: "EMPTY_QUERY",
            q: Record::new(phase(0, seed), &[false; DIM]),
            reason: "EMPTY_QUERY",
            hit: None,
        },
    ]
}
pub fn hash_record(h: &mut Sha256, r: &Record) {
    h.update(r.phase());
    for block in 0..16 {
        let mut mask = 0u64;
        for bit in 0..64 {
            if r.active(block * 64 + bit).unwrap() {
                mask |= 1 << bit;
            }
        }
        h.update(mask.to_le_bytes());
    }
}
pub fn oracle(q: &Record, b: &Record) -> Option<f64> {
    let mut total = 0.;
    let mut count = 0;
    for j in 0..DIM {
        if q.active(j).unwrap() {
            count += 1;
            if b.active(j).unwrap() {
                total += (std::f64::consts::TAU * q.phase()[j].wrapping_sub(b.phase()[j]) as f64
                    / 256.)
                    .cos();
            }
        }
    }
    (count > 0).then(|| total / count as f64)
}
pub fn topk(scores: &[SharedScore]) -> Result<Vec<(usize, f64)>> {
    let mut top: Vec<(usize, f64)> = Vec::with_capacity(10);
    for (id, s) in scores.iter().enumerate() {
        let s = s.value();
        if !s.is_finite() {
            return Err("nonfinite".into());
        }
        if top.len() == 10 && (s < top[9].1 || (s == top[9].1 && id >= top[9].0)) {
            continue;
        }
        let pos = top
            .iter()
            .position(|&(i, v)| s > v || (s == v && id < i))
            .unwrap_or(top.len());
        if pos < 10 {
            top.insert(pos, (id, s));
            if top.len() > 10 {
                top.pop();
            }
        }
    }
    Ok(top)
}
pub fn decision(top: &[(usize, f64)], support: usize) -> (&'static str, Option<usize>) {
    if support == 0 {
        return ("EMPTY_QUERY", None);
    }
    if support < 32 {
        return ("WEAK_SUPPORT", None);
    }
    if top.is_empty() {
        return ("EMPTY_BANK", None);
    }
    if top[0].1 < 0.99 {
        return ("BELOW_THRESHOLD", None);
    }
    if top.len() > 1 && top[0].1 - top[1].1 < 0.000001 {
        return ("AMBIGUOUS", None);
    }
    ("HIT", Some(top[0].0))
}
