use super::*;
fn record(id: usize, seed: u64) -> Record {
    let mut state = seed ^ id as u64;
    let phase = std::array::from_fn(|_| {
        state = state.wrapping_mul(6364136223846793005).wrapping_add(1);
        (state >> 32) as u8
    });
    let mask = std::array::from_fn(|j| match id % 5 {
        0 => true,
        1 => false,
        2 => j == DIM - 1,
        3 => j % 2 == 0,
        _ => (j + id) % 7 == 0,
    });
    Record::new(phase, &mask)
}
fn compare(
    reader: &Reader,
    q: &Query,
    bank: &PreparedBank,
    policy: Policy,
    w: usize,
    output: &mut Vec<SharedScore>,
) {
    let mut reference = Vec::new();
    let a = reader
        .scan_into(q, bank.records(), policy, w, &mut reference)
        .unwrap();
    let b = reader
        .scan_prepared_into(q, bank, policy, w, output)
        .unwrap();
    assert_eq!(a, b);
    assert_eq!(reference.len(), output.len());
    for (a, b) in reference.iter().zip(output.iter()) {
        assert_eq!(a.value().to_bits(), b.value().to_bits());
    }
}
#[test]
fn mixed_seeds_policies_and_worker_counts() {
    for seed in [0, 1, 191, u64::MAX] {
        let reader = Reader::new(seed);
        let bank = PreparedBank::new((0..33).map(|id| record(id, seed)).collect());
        let mut out = Vec::new();
        for id in 0..10 {
            let q = reader.prepare(record(id, seed));
            for policy in [Policy::Archive, Policy::BodyActivity] {
                for w in [1, 7, 64] {
                    compare(&reader, &q, &bank, policy, w, &mut out);
                }
            }
        }
    }
}
#[test]
fn allocation_stable_across_paths_empty_and_errors() {
    let r = Reader::new(1);
    let bank = PreparedBank::new((0..65).map(|i| record(i, 1)).collect());
    let mut out = Vec::new();
    r.scan_prepared_into(
        &r.prepare(record(0, 1)),
        &bank,
        Policy::BodyActivity,
        7,
        &mut out,
    )
    .unwrap();
    let ptr = out.as_ptr();
    let cap = out.capacity();
    for id in [2, 0, 1, 3, 0, 4, 1, 0] {
        compare(
            &r,
            &r.prepare(record(id, 1)),
            &bank,
            Policy::BodyActivity,
            7,
            &mut out,
        );
        assert_eq!(out.as_ptr(), ptr);
        assert_eq!(out.capacity(), cap);
        assert!(r
            .scan_prepared_into(
                &r.prepare(record(id, 1)),
                &bank,
                Policy::BodyActivity,
                0,
                &mut out
            )
            .is_err());
        assert!(out.is_empty());
        assert_eq!(out.as_ptr(), ptr);
        assert_eq!(out.capacity(), cap);
    }
}
#[test]
fn replacement_refreshes_flags_and_bounds_leave_bank_unchanged() {
    let r = Reader::new(1);
    let mut bank = PreparedBank::new(vec![record(0, 1)]);
    let mut out = Vec::new();
    let q = r.prepare(record(0, 1));
    for id in [1, 0, 3, 0] {
        bank.replace(0, record(id, 1)).unwrap();
        compare(&r, &q, &bank, Policy::BodyActivity, 7, &mut out);
    }
    let before = bank.records()[0].phase;
    assert!(bank.replace(1, record(1, 2)).is_err());
    assert_eq!(bank.records()[0].phase, before);
}
#[test]
fn spawn_failure_falls_back_after_join() {
    let r = Reader::new(1);
    let bank = PreparedBank::new((0..129).map(|i| record(i, 1)).collect());
    let q = r.prepare(record(0, 1));
    let mut expected = Vec::new();
    r.scan_into(&q, bank.records(), Policy::BodyActivity, 1, &mut expected)
        .unwrap();
    for budget in [0, 1] {
        let mut out = Vec::new();
        r.scan_prepared_with_spawn_budget(&q, &bank, Policy::BodyActivity, 7, &mut out, budget)
            .unwrap();
        assert_eq!(out.len(), expected.len());
        for (a, b) in out.iter().zip(&expected) {
            assert_eq!(a.value().to_bits(), b.value().to_bits());
        }
    }
}
#[test]
fn every_phase_delta_and_bank_resize() {
    let r = Reader::new(1);
    let q = r.prepare(Record::new([0; DIM], &[true; DIM]));
    let mut out = Vec::new();
    for n in [0, 1, 256, 5, 0, 257] {
        let bank = PreparedBank::new(
            (0..n)
                .map(|j| Record::new([j as u8; DIM], &[true; DIM]))
                .collect(),
        );
        compare(&r, &q, &bank, Policy::BodyActivity, 7, &mut out);
    }
}
