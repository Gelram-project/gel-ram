use super::*;

fn record(seed: usize, kind: usize) -> Record {
    Record::new(
        std::array::from_fn(|j| (seed * 37 + j * 19) as u8),
        &std::array::from_fn(|j| match kind {
            0 => false,
            1 => j % 16 == 0,
            2 => j % 2 == 0,
            _ => true,
        }),
    )
}
fn compare(reader: &Reader, q: &Query, bank: &PreparedBank, p: Policy, w: usize) {
    let mut baseline = Vec::new();
    let mut sparse = Vec::new();
    let a = reader.scan_prepared_into(q, bank, p, w, &mut baseline);
    let b = reader.scan_sparse_into(q, bank, p, w, &mut sparse);
    assert_eq!(a, b);
    assert_eq!(
        baseline
            .iter()
            .map(|x| x.value().to_bits())
            .collect::<Vec<_>>(),
        sparse
            .iter()
            .map(|x| x.value().to_bits())
            .collect::<Vec<_>>()
    );
    if q.active.is_empty() {
        assert!(sparse.is_empty());
    } else {
        for (body, value) in bank.records().iter().zip(&sparse) {
            assert_eq!(
                value.value().to_bits(),
                reader.read(q, body, p).unwrap().value().to_bits()
            );
        }
    }
}
#[test]
fn all_mask_types_policies_workers_and_empty_queries() {
    assert_eq!(std::mem::size_of::<Activity>(), 1);
    let r = Reader::new(4093);
    let b = PreparedBank::new((0..129).map(|i| record(i, i % 4)).collect());
    assert_eq!(b.flags_bytes(), 129);
    for support in [0, 1, 64, 512, DIM] {
        let q = r.prepare(Record::new(
            [231; DIM],
            &std::array::from_fn(|j| j < support),
        ));
        for p in [Policy::BodyActivity, Policy::Archive] {
            for w in [1, 7, 64] {
                compare(&r, &q, &b, p, w);
            }
        }
    }
}
#[test]
fn every_phase_empty_body_zero_bits_and_archive_is_not_skipped() {
    let r = Reader::new(4093);
    let b = PreparedBank::new(vec![Record::new([0; DIM], &[false; DIM])]);
    for phase in 0..=255 {
        for support in [1, 64, DIM] {
            let q = r.prepare(Record::new(
                [phase; DIM],
                &std::array::from_fn(|j| j < support),
            ));
            compare(&r, &q, &b, Policy::BodyActivity, 1);
            compare(&r, &q, &b, Policy::Archive, 1);
            assert_eq!(
                r.read(&q, &b.records()[0], Policy::BodyActivity)
                    .unwrap()
                    .value()
                    .to_bits(),
                0f64.to_bits()
            );
        }
    }
    let q = r.prepare(Record::new([0; DIM], &[true; DIM]));
    let mut out = Vec::new();
    r.scan_sparse_into(&q, &b, Policy::Archive, 1, &mut out)
        .unwrap();
    assert_eq!(out[0].value(), 1.);
}
#[test]
fn replacements_keep_classification_and_allocation_coherent() {
    let r = Reader::new(9);
    let mut b = PreparedBank::new(vec![record(0, 0)]);
    let q = r.prepare(record(0, 3));
    let flags = b.flags_bytes();
    for previous in 0..4 {
        for next in 0..4 {
            b.replace(0, record(0, previous)).unwrap();
            b.replace(0, record(1, next)).unwrap();
            assert_eq!(b.full[0], classify(&b.records()[0]));
            assert_eq!(flags, b.flags_bytes());
            for p in [Policy::Archive, Policy::BodyActivity] {
                compare(&r, &q, &b, p, 1);
            }
        }
    }
    let before = b.full[0];
    assert!(b.replace(1, record(0, 0)).is_err());
    assert_eq!(b.full[0], before);
}
#[test]
fn forced_spawn_failure_partial_and_full_scans() {
    let r = Reader::new(19);
    let b = PreparedBank::new((0..129).map(|i| record(i, i % 4)).collect());
    for kind in [1, 3] {
        let q = r.prepare(record(0, kind));
        let mut expected = Vec::new();
        r.scan_into(&q, b.records(), Policy::BodyActivity, 1, &mut expected)
            .unwrap();
        for budget in [0, 1] {
            let mut out = Vec::new();
            r.scan_sparse_with_spawn_budget(&q, &b, Policy::BodyActivity, 7, &mut out, budget)
                .unwrap();
            assert_eq!(
                expected
                    .iter()
                    .map(|x| x.value().to_bits())
                    .collect::<Vec<_>>(),
                out.iter().map(|x| x.value().to_bits()).collect::<Vec<_>>()
            );
        }
    }
}
#[test]
fn stale_output_empty_bank_query_and_worker_error() {
    let r = Reader::new(4);
    let b = PreparedBank::new(vec![record(0, 3), record(1, 0)]);
    let q = r.prepare(record(0, 3));
    let mut out = Vec::new();
    r.scan_sparse_into(&q, &b, Policy::BodyActivity, 1, &mut out)
        .unwrap();
    let pointer = out.as_ptr();
    let cap = out.capacity();
    assert_eq!(
        r.scan_sparse_into(
            &r.prepare(record(0, 0)),
            &b,
            Policy::BodyActivity,
            1,
            &mut out
        ),
        Ok(false)
    );
    assert!(out.is_empty());
    assert!(r
        .scan_sparse_into(&q, &b, Policy::BodyActivity, 0, &mut out)
        .is_err());
    assert!(out.is_empty());
    assert_eq!(
        r.scan_sparse_into(
            &q,
            &PreparedBank::new(vec![]),
            Policy::BodyActivity,
            1,
            &mut out
        ),
        Ok(true)
    );
    assert!(out.is_empty());
    r.scan_sparse_into(&q, &b, Policy::BodyActivity, 1, &mut out)
        .unwrap();
    assert_eq!((pointer, cap), (out.as_ptr(), out.capacity()));
}
