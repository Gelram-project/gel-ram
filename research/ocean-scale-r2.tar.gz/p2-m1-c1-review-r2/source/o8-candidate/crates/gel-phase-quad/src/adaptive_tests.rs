use super::*;
fn rec(empty: bool) -> Record {
    Record::new([37; DIM], &[!empty; DIM])
}
#[test]
fn counter_transitions_bounds_and_fixed_overhead() {
    let mut b = PreparedBank::new(vec![rec(false); 3]);
    assert_eq!(b.empty_count(), 0);
    let flags = b.flags_bytes();
    for sequence in [[true, true, false, false], [false, true, false, true]] {
        for empty in sequence {
            for i in 0..3 {
                b.replace(i, rec(empty)).unwrap();
                assert_eq!(
                    b.empty_count(),
                    b.records()
                        .iter()
                        .filter(|r| r.active_mask().iter().all(|&a| !a))
                        .count()
                );
                assert_eq!(b.flags_bytes(), flags);
            }
        }
    }
    let count = b.empty_count();
    assert!(b.replace(3, rec(true)).is_err());
    assert_eq!(count, b.empty_count());
    assert_eq!(
        std::mem::size_of::<PreparedBank>(),
        std::mem::size_of::<Vec<Record>>()
            + std::mem::size_of::<Vec<Activity>>()
            + std::mem::size_of::<usize>()
    );
    assert_eq!(std::mem::size_of::<Activity>(), 1);
}
#[test]
fn all_routes_policies_and_replacements_are_bit_equal() {
    let r = Reader::new(773);
    let mut b = PreparedBank::new(vec![rec(false); 17]);
    for empty in [false, true, false, true] {
        b.replace(0, rec(empty)).unwrap();
        for count in [0, 1, 64, DIM] {
            let q = r.prepare(Record::new([37; DIM], &std::array::from_fn(|j| j < count)));
            for p in [Policy::Archive, Policy::BodyActivity] {
                for w in [1, 7] {
                    let mut a = Vec::new();
                    let mut c = Vec::new();
                    assert_eq!(
                        r.scan_into(&q, b.records(), p, w, &mut a),
                        r.scan_adaptive_into(&q, &b, p, w, &mut c)
                    );
                    assert_eq!(
                        a.iter().map(|s| s.value().to_bits()).collect::<Vec<_>>(),
                        c.iter().map(|s| s.value().to_bits()).collect::<Vec<_>>()
                    );
                }
            }
        }
    }
}
#[test]
fn adaptive_reuses_output_and_clears_errors() {
    let r = Reader::new(1);
    let q = r.prepare(rec(false));
    let mut b = PreparedBank::new(vec![rec(false); 5]);
    let mut out = Vec::new();
    r.scan_adaptive_into(&q, &b, Policy::BodyActivity, 1, &mut out)
        .unwrap();
    let before = (out.as_ptr(), out.capacity());
    for empty in [true, false, true] {
        b.replace(1, rec(empty)).unwrap();
        r.scan_adaptive_into(&q, &b, Policy::BodyActivity, 1, &mut out)
            .unwrap();
        assert_eq!(before, (out.as_ptr(), out.capacity()));
    }
    assert!(r
        .scan_adaptive_into(&q, &b, Policy::BodyActivity, 0, &mut out)
        .is_err());
    assert!(out.is_empty());
    assert_eq!(
        r.scan_adaptive_into(&r.prepare(rec(true)), &b, Policy::BodyActivity, 1, &mut out),
        Ok(false)
    );
    assert!(out.is_empty());
    assert_eq!(
        r.scan_adaptive_into(&q, &PreparedBank::new(vec![]), Policy::Archive, 1, &mut out),
        Ok(true)
    );
    assert!(out.is_empty());
}
