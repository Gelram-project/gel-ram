use std::{
    fs,
    path::PathBuf,
    process::Command,
    sync::atomic::{AtomicU64, Ordering},
};
struct Temp(PathBuf);
impl Temp {
    fn new() -> Self {
        static N: AtomicU64 = AtomicU64::new(0);
        for _ in 0..1000 {
            let p = std::env::temp_dir().join(format!(
                "gel-t9-test-{}-{}",
                std::process::id(),
                N.fetch_add(1, Ordering::Relaxed)
            ));
            if fs::create_dir(&p).is_ok() {
                return Self(p);
            }
        }
        panic!("temp");
    }
}
impl Drop for Temp {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.0);
    }
}
#[test]
fn corrupted_tail_evidence_fails() {
    let d = Temp::new();
    let p = d.0.join("run");
    let build = Command::new(env!("CARGO_BIN_EXE_search_tail_t9"))
        .args(["256", "7", "9871", "3"])
        .arg(&p)
        .output()
        .unwrap();
    assert!(build.status.success());
    let audit = || {
        Command::new(env!("CARGO_BIN_EXE_tail_recheck"))
            .arg(&p)
            .args(["256", "7", "9871", "3"])
            .output()
            .unwrap()
            .status
            .success()
    };
    assert!(audit());
    for (file, from, to) in [
        ("manifest.txt", "SEED=9871", "SEED=2027"),
        ("summary.txt", "ROWS=21", "ROWS=22"),
        ("queries.csv", ",HIT,", ",UNKNOWN,"),
        ("timings.csv", ",HIT,", ",UNKNOWN,"),
        ("COMPLETE", "PASS", "FAIL"),
    ] {
        let path = p.join(file);
        let old = fs::read_to_string(&path).unwrap();
        assert!(old.contains(from));
        fs::write(&path, old.replacen(from, to, 1)).unwrap();
        assert!(!audit(), "{file}");
        fs::write(path, old).unwrap();
    }
    for file in ["queries.csv", "timings.csv", "top10.csv"] {
        let path = p.join(file);
        let old = fs::read_to_string(&path).unwrap();
        fs::write(&path, format!("{old}{}\n", old.lines().nth(1).unwrap())).unwrap();
        assert!(!audit(), "duplicate {file}");
        fs::write(path, old).unwrap();
    }
    assert!(audit());
}
