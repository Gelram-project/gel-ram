# Measured results and limits

Rust 1.85.0, AMD Ryzen AI 9 HX 370, Linux. Synthetic numerical Q8 banks.
**A full 10M scan takes hundreds of milliseconds, not microseconds.**
Addressed access and a full ranked search are not the same operation.

## C1: same reader, worker count comparison

EXACT end-to-end p50, milliseconds; each cell aggregates 18 observations
(three seeds, six cycles). Includes scan, top10 reduction and decision.

| Bank | 1 worker | 12 workers | 24 workers |
|---|---:|---:|---:|
| 1M | 474.440 | 77.408 | 58.417 |
| 10M | 4669.727 | 632.334 | 498.265 |

Median paired 1/24-worker speedup: 8.12× at 1M and 9.42× at 10M.
This is not a comparison against a different public release or an LLM.
756 operations, 594M score-bit comparisons, 47,952 oracle checks.
All expected results passed. Raw records and independently recomputed
statistics: [C1 evidence](evidence/contention-c1/).

## R10: longer repeated campaign — all runs retained

24 workers, EXACT, 100 observations per cell. Milliseconds.

| Bank | Seed | p50 | p95 | p99 | max |
|---|---:|---:|---:|---:|---:|
| 1M | 41119 | 72.427 | 81.018 | 82.859 | 90.949 |
| 1M | 61141 | 71.962 | 79.860 | 80.576 | 88.227 |
| 10M | 41119 | 615.428 | 684.888 | 710.313 | 734.085 |
| 10M | 61141 | 704.995 | 757.900 | 783.038 | 810.236 |

These slower results are not hidden behind the short C1 result.
Seeds and host state differ; no controlled attribution of the slowdown.
N=100 is insufficient for a stable extreme-tail claim; p99 is also sensitive
to individual observations. No headline p99.9–p99.999 claim.

2,800 operations: 2,400 full scans and 400 EMPTY fast-path requests.
660M score-bit comparisons; 177,600 oracle checks passed. Seven classes:
EXACT, NEAR, PARTIAL, MISS, WEAK, TIE, EMPTY. TIE repeats one distinct query.
Seeds were already used in C1; this is not an independent semantic held-out.
See [raw evidence and per-class statistics](evidence/repeat-r10/).

## P2: persistence and replay

Whole measured actions, seconds; a single observation each, not percentiles.

| Bank | Initial save | Replay/load after commits | Checkpoint | Reload checkpoint |
|---|---:|---:|---:|---:|
| 1M | 3.400 | 1.545 | 1.272 | 1.392 |
| 10M | 29.452 | 13.184 | 10.976 | 13.097 |

Four incremental operations per bank; reconstructed records and rankings
match after restart. 99M score-bit comparisons passed. Separate small-bank
tests inject SIGKILL at 12 protocol hooks: not a 10M crash campaign and not
a physical power-cut test. Evidence: [P2](evidence/persistence-p2/).

## M1: sealed-copy mapping, not zero-copy disk access

| Bank | Copy + seal + verify | Buffered load + decode | All-slot comparison |
|---|---:|---:|---:|
| 1M | 1.039 s | 1.336 s | 2.518 s |
| 10M | 7.016 s | 13.835 s | 24.827 s |

11,000,002 slot comparisons passed, including tombstones. Measured RSS after
mapping: 1,128,180 / 11,261,944 KiB; process HWM with the comparison heap bank:
2,261,004 / 22,590,080 KiB. Do not present this duplicated comparison layout
as the minimum production RAM budget. Evidence: [M1](evidence/mapping-m1/).

## What these results do not establish

Semantic AI accuracy, natural conversation, private P2P readiness, hardware
DRAM-refresh synchronization, physical PUF, encrypted user memory, multi-host
scaling, Windows/macOS support, or behaviour after actual power loss.
Hashes provide integrity against pinned trusted inputs, not authenticity
against an attacker controlling both data and the trusted anchor.
