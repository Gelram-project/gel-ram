# Source boundary

O8 and T9 are unchanged experimental reader/producers from the preceding
review. O8 includes the original public core reader snapshot at local HEAD
`1079aacfeccae7e337296f332fdb2e8bed94b2e0`, with standalone Cargo metadata.
P2, M1 and C1 are new local laboratory modules; all remain unpublished.

P2/M1 production sources were frozen for their respective campaigns.
Supplementary tests were added afterwards without changing their measured
runtime implementation. C1 runs the unchanged T9 binary; its separate
rechecker recalculates statistics from raw observations after collection.
Export-only Cargo metadata adds `license-file = "LICENSE"` to laboratory
packages lacking it, with an unchanged copy of the current GEL license.
This changes package metadata, not the measured Rust runtime source.
The prior export's stratified public-reader test, tail-evidence regressions
and tail-rechecker dimension guards are retained in the appropriate packages.

The export is allowlisted by `package_p2_m1_c1.rs`, not a recursive copy of
the working directory. No compiled binaries, full synthetic snapshot banks,
trust directories, model files, user content or private application are shipped.
Compiler logs and absolute-path environment dumps are not copied. Numerical
logs and source files retain their measured values. Integrity manifests are
checksums, not authenticated signatures against an adversarial distributor.

R2 is a separate copy of that reviewed export with the documented verification
and manual-reproduction fixes in CHANGES-R2.md. The included packaging tool
records the initial allowlisted export stage; it is not a standalone generator
of this R2 tree. Its laboratory input directories are intentionally not shipped.
Measured reader/storage code and raw measurement logs are byte-identical to R1.

Included Cargo.lock files pin exact dependency checksums. `source/vendor`
holds their sources and original license texts. GEL's license does not override
those licenses. This is a technical inventory, not a legal opinion.
