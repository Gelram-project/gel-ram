# Final technical and disclosure review

## Checks completed

- Allowlisted export, no recursive copy of a private application or dirty public
  worktree. Five laboratory workspaces and their exact vendored dependencies.
- No full 1M/10M banks, model weights, compiled executables, trust directories,
  personal conversation files or private application components included.
- No symlinks or files above 5 MiB observed before freezing this snapshot.
- Targeted scans found no personal absolute home paths, private application
  version labels, personal name, private-key blocks or common access-token
  prefixes outside vendored upstream sources. This is not proof that every
  possible secret pattern or malicious construct is absent.
- First-party process launches are local build/test/recheck/campaign tools;
  no first-party HTTP client, download command or socket path was found in
  the scanned source. Clean verification also ran with network isolation.
- P2 writer exclusion and M1 unsafe boundaries reviewed. Path security depends
  on owner-controlled directories; this is explicitly not protection against
  a hostile administrator or adversarial parent-directory replacement.
- Cargo lock/checksum inventory covers 12 upstream versions. Their license
  texts and notices are retained. No paid scanner or cloud runner was used.
- Original measurement source/binary pins still match. Export changes are
  limited to documented Cargo licensing metadata, tests and verification tools.
- The chart is generated from C1 CSV, not illustrated or manually invented.
  Longer, slower R10 runs are retained and linked next to the chart.

## License and approval boundary

Root LICENSE is unchanged from the checked public main commit
`1079aacfeccae7e337296f332fdb2e8bed94b2e0`, SHA256:
`c0b560ffc53ad735c4a6236356ff0cd47d92cf671181e799917975b071e8cd40`.
It is GEL RAM Noncommercial Reciprocal License 1.0, not AGPL and not an
unmodified PolyForm license. Public author identity remains the pseudonym RR;
the previously public licensing email is retained in NOTICE and LICENSE.
No legal guarantee or new commercial terms are created by this review.

Publishing this bundle would reveal the source of O8/T9/P2/M1/C1, including
the selected reader optimization, journal format and mapping implementation.
It is therefore more than a demonstration that conceals all implementation.
The private speaker, private bank data and private full P2P application remain
excluded. The owner approved this selected disclosure scope in the follow-up
request. This is recorded separately from legal review and actual publication.

Review status is not a substitute for publication approval. Tests do not turn
LEGAL_APPROVED or PUBLICATION_APPROVED to YES. Linux-only is an explicit scope;
no Windows/macOS support or paid services are promised.

Older videos and earlier packages are not changed or repurposed as evidence
for these measurements. This bundle uses source, CSV, test output and a chart.
