# GEL Ocean — persistence, safe mapping and worker scaling

**Offline laboratory review bundle, not a public release.** Rust1.85.0, Linux.
No private application, user knowledge, conversations, keys or model weights.

R3 adds a scaled memory reserve for the small P2 verification fixture.
See [CHANGES-R3.md](CHANGES-R3.md); historical R1/R2 measurements are preserved.

This extends the earlier O8/T9 reader review with runnable Rust code:

- P2: immutable snapshots, bounded incremental journal, trusted generation
  selection, insert/update/tombstones and fail-closed recovery.
- M1: a snapshot copied into kernel-sealed memfd and mapped read-only;
  complete structural/hash validation before record access.
- C1: the frozen T9 producer exercised at1/12/24 workers with new seeds,
  raw timings and independent cross-worker evidence checks.

See `reports/` for measured results and explicit limitations. Test data is
synthetic numerical Q8, **not** a semantic AI benchmark. Addressed reads,
full scans, source copying and decoding are different operations.

![Measured worker-count comparison](media/c1-worker-scaling.svg)

The longer R10 campaign was slower: 10M/24-worker EXACT p50 was 615–705 ms,
not the short C1 median of 498 ms. Read [all results and limits](RESULTS.md).

## One-command verification after compiling the tiny Rust launcher

```sh
rustc +1.85.0 --edition 2021 tools/verify_review.rs -o ../gel-review-verify
../gel-review-verify . ../gel-review-evidence
```

The evidence directory must be new. The launcher checks hashes, runs tests,
builds all tools with a fresh Cargo home and recalculates the included C1/R10
statistics, checks the C1→R10 query/top10 prefix, and cross-checks the P2/M1
checkpoint pins, generations, counts, rankings and timing fields. The storage
check validates saved log consistency; it does not rerun the 10M storage bank.
It also rejects extra unlisted files, missing files, unsafe paths
and symlinks, and runs its own manifest and storage regression tests. It does not run the
costly1M/10M campaigns or publish anything. Keep build outputs outside the bundle.

## Prepare a working copy for manual tests

Install Rust 1.85.0 beforehand. Dependencies are included in `source/vendor`.
Keep the reviewed bundle unchanged: the strict verifier rejects unlisted build
outputs. From the bundle root, create this separate working copy once:

```sh
test ! -e ../gel-ocean-work && cp -a source ../gel-ocean-work
```

## Quick local tests

Run in the working copy, not in the immutable bundle:

```sh
cd ../gel-ocean-work
env -u CARGO_TARGET_DIR cargo +1.85.0 test --locked --offline --manifest-path o8-candidate/Cargo.toml --workspace
env -u CARGO_TARGET_DIR cargo +1.85.0 test --locked --offline --manifest-path t9-candidate/Cargo.toml
env -u CARGO_TARGET_DIR cargo +1.85.0 test --locked --offline --manifest-path p2-candidate/Cargo.toml
env -u CARGO_TARGET_DIR cargo +1.85.0 test --locked --offline --manifest-path m1-candidate/Cargo.toml
env -u CARGO_TARGET_DIR cargo +1.85.0 test --locked --offline --manifest-path c1-candidate/Cargo.toml
```

P2 crash tests kill only their own temporary test children, not your desktop
or host. They do not prove power-loss safety. The tests contain no private data.

## Reproduce large experiments — opt-in

Continue from `gel-ocean-work/` after building all binaries. The output directories must
not already exist; existing evidence is never overwritten:

```sh
env -u CARGO_TARGET_DIR cargo +1.85.0 build --locked --offline --release --manifest-path p2-candidate/Cargo.toml --bins
env -u CARGO_TARGET_DIR cargo +1.85.0 build --locked --offline --release --manifest-path m1-candidate/Cargo.toml --bins
env -u CARGO_TARGET_DIR cargo +1.85.0 build --locked --offline --release --manifest-path t9-candidate/Cargo.toml --bins
env -u CARGO_TARGET_DIR cargo +1.85.0 build --locked --offline --release --manifest-path c1-candidate/Cargo.toml --bins
./p2-candidate/target/release/p2_campaign
./m1-candidate/target/release/m1_campaign
./c1-candidate/target/release/gel-c1-lab
./c1-candidate/target/release/c1_recheck contention-c1
```

For the optional R10 repeat, compile `tools/r10_campaign.rs` from the original
bundle into a binary outside it. Run that binary with `gel-ocean-work/` as the
current directory, after building T9 above. It intentionally resolves the
producer as `t9-candidate/target/release/search_tail_t9` and refuses to overwrite
an existing `repeat-r10/` result directory.

These monitored runners currently require the tested Linux `/proc` and AMD
`k10temp` sensor. They fail closed if monitoring is unavailable. Keep at least
~35GiB available RAM for the large mapping comparison and >46GiB free disk
for generation/checkpoints plus reserve; CPU stop85°C. Actual guards in code
remain authoritative. Do not disable the guards to force a run on a small PC.
Full runs are not the default unit-test job. No cloud service or fee is needed.

To recheck the included C1 evidence, give the rechecker the path to
`evidence/contention-c1` in a copy with generated `RECHECKED`,
`rechecked-stats.csv` and `paired-speedups.csv` removed from that copy only;
it intentionally refuses to overwrite those outputs. Keep the original bundle.

## Trust and scope

The anchor must come from an owner-controlled trust directory, optionally
pinned independently. SHA256 is not a signature. Sealed mappings are not
encryption, hardware PUF, DRAM-refresh synchronization or proof of AI reasoning.
P2/M1 must not replace encrypted personal memory without a separate integration.
There are no1M/10M bank files in this bundle; regenerate them locally.

Publication and legal review remain separate approvals. The proposed export
uses the existing GEL RAM Noncommercial Reciprocal License1.0, included
unchanged in LICENSE; it does not replace third-party licenses. Preparing
this local candidate does not approve publication of previously private material.
