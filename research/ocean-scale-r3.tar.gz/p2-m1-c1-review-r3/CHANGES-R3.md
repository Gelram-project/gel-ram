# R3 — small-verifier memory admission fix

R3 is a new source snapshot, not a replacement of historical R2 evidence.
The PR review found that the 128-row P2 crash/replay fixture was incorrectly
subject to a fixed 8 GiB free-memory reserve.

Only the P2 probe's ranking admission estimate changed: headroom now scales
with row count, with a 64 MiB floor and the original 8 GiB at 1M rows and above.
The 1280-byte-per-row estimate and strict available-memory comparison remain.
Checked arithmetic rejects overflow. Three regression tests cover the small
fixture, unchanged large-campaign estimates, monotonicity and overflow.

This does not remove the large-campaign resource guards, promise operation
under every cgroup limit, or change scoring, storage format or ranking.
M1 and the opt-in campaign launchers retain their large-run guards.

The full small verifier is checked with a synthetic /proc/meminfo reporting
5 GiB available, mounted only inside an isolated test namespace. This checks
the admission path; it is not a measurement on a physical 5 GiB machine.
No host memory or kernel settings are modified by this test.

Observed locally: the R2 probe failed with "rank memory reserve"; the R3
probe verified the same 128-row snapshot and all three ranking decisions.
The full isolated verifier passed 103 Cargo tests, 3 inventory tests and
5 storage-log tests (111 total), followed by the saved-evidence rechecks.
The first sandbox invocation failed before any tests because /dev was not
set up; the successful invocation added a private /dev mount. This was a
test-environment error, not a failed product assertion.

Historical raw benchmark evidence, plots and license texts are unchanged.
Historical validation/status documents retain their R1/R2 context. New source
manifests describe R3. R2 packaging scripts are retained as historical tools,
not instructions that produce an exact R3 snapshot.
